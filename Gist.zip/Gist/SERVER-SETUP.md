# Setting up the AI notes server

Goal: a small AI model running on your Proxmox server that Gist can reach from anywhere over
Tailscale. About 20 minutes. Everything below runs on a machine that has 8 GB of RAM and no
graphics card, so the plan uses a small model and gives it its own container.

## 1. Create a container for it (Proxmox web page)

1. Datacenter -> your node -> local (storage) -> CT Templates -> download **debian-12-standard**.
2. Click **Create CT**:
   - Hostname: `gist-ai`
   - Password: choose one
   - Template: the Debian 12 one
   - Disk: 12 GB (the model is about 2 GB)
   - CPU: 4 cores
   - Memory: **4096 MB**, swap 1024 MB (the cap keeps it from starving Crafty)
   - Network: DHCP is fine
   - Leave "Unprivileged container" ticked
3. Do not start it yet.

## 2. Let the container use Tailscale

In the Proxmox **host** shell, replace `105` with your container's ID number:

    nano /etc/pve/lxc/105.conf

Add these two lines at the bottom, save, then start the container:

    lxc.cgroup2.devices.allow: c 10:200 rwm
    lxc.mount.entry: /dev/net/tun dev/net/tun none bind,create=file

## 3. Install the basics and Tailscale (inside the container)

Open the container's Console and log in as root:

    apt update && apt install -y curl zstd
    curl -fsSL https://tailscale.com/install.sh | sh
    tailscale up

Open the link it prints and sign in with the same Tailscale account you use on your phone.
Then run `tailscale ip -4` and note the address that starts with 100. (Remember it.)

## 4. Install Ollama and the model

    curl -fsSL https://ollama.com/install.sh | sh
    ollama pull qwen2.5:3b

Quick test (it should answer in a few seconds):

    ollama run qwen2.5:3b "Say hello in five words"

Type `/bye` to leave.

## 5. Make it reachable over Tailscale

    systemctl edit ollama

In the editor that opens, add these lines between the comments, then save:

    [Service]
    Environment="OLLAMA_HOST=0.0.0.0:11434"
    Environment="OLLAMA_KEEP_ALIVE=15m"

Then:

    systemctl restart ollama
    curl http://localhost:11434/api/tags

You should see your model listed.

## 6. Connect Gist

1. On the phone, install **Tailscale**, sign in, and switch it on.
2. In Gist open **Settings**, and under AI notes enter the server address: either the
   container's Tailscale name (`gist-ai`) or the 100.x address from step 3.
3. Leave the model as `qwen2.5:3b` and tap **Test connection**. It should say it's connected
   and the model is installed.
4. Open a lecture, go to the **Notes** tab and tap **Write notes**.

## Good to know

- **Speed.** Expect roughly 10 to 20 minutes for a one-hour lecture on this processor. Gist
  works through the lecture in about ten-minute parts and keeps going in the background. If the
  server or Tailscale drops out, it waits and carries on from the last finished part.
- **Memory.** Check with `ollama ps` while it runs. If Crafty has players on and things feel
  tight, schedule notes for later or turn the container memory up (16 GB of RAM would help a lot).
- **Other models.** `llama3.2:3b` and `gemma2:2b` also fit. Pull one, then pick it in Gist's
  Settings (Test connection lists what's installed, and you can tap one to use it).
- **Security.** Ollama has no password. Don't forward port 11434 on your router. It is then
  reachable only from your home network and your own Tailscale devices.
- **Troubleshooting.** "Couldn't reach your server": check Tailscale is on in the phone app and
  `tailscale status` in the container shows it online. "Model isn't installed": run
  `ollama pull <model name>` in the container. If `tailscale up` complains about `/dev/net/tun`,
  recheck the two lines in step 2 and restart the container.
