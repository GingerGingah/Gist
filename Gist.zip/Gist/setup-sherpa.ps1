# One-time setup: downloads the sherpa-onnx speech runtime and adds it to this project.
#
# Run from the project folder (the one containing this file):
#   powershell -ExecutionPolicy Bypass -File .\setup-sherpa.ps1
#
# It adds two things:
#   1. the native libraries (arm64) into app\src\main\jniLibs\arm64-v8a
#   2. the Kotlin wrapper sources into app\src\main\java\com\k2fsa\sherpa\onnx
#
# Options:
#   -Version 1.x.y                  a different release (no leading "v")
#   -SevenZipPath "C:\...\7z.exe"   tell the script where 7-Zip is, if it can't find it
param(
    [string]$Version = "1.13.8",
    [string]$SevenZipPath = ""
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # makes big downloads much faster in Windows PowerShell

function Find-7Zip {
    if ($SevenZipPath -and (Test-Path $SevenZipPath)) { return $SevenZipPath }

    $candidates = @(
        "$env:ProgramFiles\7-Zip\7z.exe",
        "${env:ProgramFiles(x86)}\7-Zip\7z.exe",
        "$env:LOCALAPPDATA\Programs\7-Zip\7z.exe",
        "$env:USERPROFILE\scoop\apps\7zip\current\7z.exe"
    )
    # 7-Zip records its install folder in the registry.
    foreach ($key in @("HKLM:\SOFTWARE\7-Zip", "HKCU:\SOFTWARE\7-Zip", "HKLM:\SOFTWARE\WOW6432Node\7-Zip")) {
        foreach ($name in @("Path64", "Path")) {
            $dir = (Get-ItemProperty -Path $key -Name $name -ErrorAction SilentlyContinue).$name
            if ($dir) { $candidates += (Join-Path $dir "7z.exe") }
        }
    }
    foreach ($p in $candidates) {
        if (Test-Path $p) { return $p }
    }
    $cmd = Get-Command 7z -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    return $null
}

# A .tar.bz2 is two layers: bzip2 on the outside, tar inside. 7-Zip unwraps one layer per run.
function Expand-With7Zip([string]$sevenZip, [string]$archive, [string]$tarFile, [string]$dest) {
    $work = Split-Path -Parent $archive
    & $sevenZip x $archive "-o$work" -y | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "7-Zip couldn't open the download." }
    & $sevenZip x $tarFile "-o$dest" -y | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "7-Zip couldn't unpack the files inside the download." }
}

function Expand-TarBz2([string]$archive, [string]$dest) {
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    $work = Split-Path -Parent $archive
    $tarFile = Join-Path $work ([System.IO.Path]::GetFileNameWithoutExtension($archive))

    $sevenZip = Find-7Zip
    if ($sevenZip) {
        Write-Host "     Unpacking with 7-Zip..."
        Expand-With7Zip $sevenZip $archive $tarFile $dest
        return
    }

    # No 7-Zip: use the bzip2 that comes with Git, then Windows' own tar for the second layer.
    $gitBzip = Join-Path $env:ProgramFiles "Git\usr\bin\bzip2.exe"
    if (Test-Path $gitBzip) {
        Write-Host "     Unpacking with Git's bzip2..."
        & $gitBzip -dk $archive
        if ($LASTEXITCODE -ne 0) { throw "bzip2 couldn't open the download." }
        & (Join-Path $env:SystemRoot "System32\tar.exe") -xf $tarFile -C $dest
        if ($LASTEXITCODE -ne 0) { throw "tar couldn't unpack the files inside the download." }
        return
    }

    Write-Host "     No unpacking tool found. Installing 7-Zip with winget..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install --id 7zip.7zip -e --accept-package-agreements --accept-source-agreements
        $sevenZip = Find-7Zip
    }
    if (-not $sevenZip) {
        throw "Couldn't find 7-Zip. Run again with its location, for example: .\setup-sherpa.ps1 -SevenZipPath 'C:\Program Files\7-Zip\7z.exe'"
    }
    Expand-With7Zip $sevenZip $archive $tarFile $dest
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tmp = Join-Path $env:TEMP "gist-sherpa-$Version"
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Path $tmp | Out-Null

Write-Host "1/2  Downloading the native libraries (v$Version)..."
$libArchive = Join-Path $tmp "android.tar.bz2"
Invoke-WebRequest -Uri "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$Version/sherpa-onnx-v$Version-android.tar.bz2" -OutFile $libArchive
$libOut = Join-Path $tmp "libs"
Expand-TarBz2 $libArchive $libOut
$arm = Get-ChildItem $libOut -Recurse -Directory -Filter "arm64-v8a" | Select-Object -First 1
if (-not $arm) { throw "Couldn't find the arm64-v8a libraries inside the download." }
$jni = Join-Path $root "app\src\main\jniLibs\arm64-v8a"
New-Item -ItemType Directory -Path $jni -Force | Out-Null
Copy-Item (Join-Path $arm.FullName "*.so") $jni -Force

Write-Host "2/2  Downloading the Kotlin wrapper sources..."
$srcZip = Join-Path $tmp "source.zip"
Invoke-WebRequest -Uri "https://github.com/k2-fsa/sherpa-onnx/archive/refs/tags/v$Version.zip" -OutFile $srcZip
$srcOut = Join-Path $tmp "src"
Expand-Archive $srcZip -DestinationPath $srcOut
$kt = Get-ChildItem $srcOut -Recurse -Directory -Filter "kotlin-api" | Select-Object -First 1
if (-not $kt) { throw "Couldn't find the kotlin-api folder in the source download." }
$dest = Join-Path $root "app\src\main\java\com\k2fsa\sherpa\onnx"
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item (Join-Path $kt.FullName "*.kt") $dest -Force

Remove-Item $tmp -Recurse -Force
Write-Host ""
Write-Host "Done. In Android Studio choose File -> Sync Project with Gradle Files, then run the app."
