package com.gist.gist.ai

import android.content.Context

/** Something that can answer a question: the home server, or the small AI on the phone. */
interface LlmBackend {
    /** Shown on the finished notes ("Written by ..."). */
    val label: String

    /** How much transcript to give it at a time. Small models need smaller pieces. */
    val wordsPerPart: Int

    /** How much of the part-by-part notes the final overview can read. */
    val digestChars: Int

    /** True if the work happens on this phone, so it should wait while a lecture is recording. */
    val onThisPhone: Boolean

    suspend fun chat(system: String, user: String, bigContext: Boolean = false): String
}

class ServerBackend(private val client: OllamaClient, private val model: String) : LlmBackend {
    override val label = model
    override val wordsPerPart = 1_100
    override val digestChars = 18_000
    override val onThisPhone = false

    override suspend fun chat(system: String, user: String, bigContext: Boolean): String =
        client.chat(
            system, user,
            numCtx = if (bigContext) 8192 else 4096,
            maxTokens = if (bigContext) 900 else 600,
        )
}

class DeviceBackend(private val context: Context) : LlmBackend {
    override val label = "Offline AI (Qwen 2.5 1.5B, on this phone)"
    override val wordsPerPart = 550
    override val digestChars = 6_500
    override val onThisPhone = true

    override suspend fun chat(system: String, user: String, bigContext: Boolean): String =
        OnDeviceLlm.complete(context, system, user)
}
