package com.gist.gist.fixes

import android.content.Context
import com.gist.gist.ai.OnDeviceLlm
import com.gist.gist.data.FixState
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.data.TranscriptFixes
import com.gist.gist.recording.RecState
import com.gist.gist.recording.RecordingSession
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

/**
 * A basic proofreader that runs on the phone. It reads the transcript a few lines at a time,
 * with the lines just before for context, and asks the small offline AI to fix only words that
 * are clearly wrong for the context, such as "cash" where "cache" is meant in a talk about CPUs.
 *
 * A small model can be over-eager, so every suggestion has to pass strict checks before it is
 * kept: the same number of words, only a few changed, and each change must look like a
 * mishearing of the original word. Anything else is thrown away and the original stays.
 * The original transcript is never edited; corrections are saved on the side and can be undone.
 */
object TranscriptCorrector {

    private const val BATCH = 6
    private const val CONTEXT_LINES = 2

    private const val SYSTEM = "You proofread automatic speech recognition transcripts of lectures. " +
        "Fix only words that are clearly wrong given the surrounding context, such as a word " +
        "that sounds like the intended word (for example \"cash\" where \"cache\" is meant in a " +
        "lecture about computers). Never rephrase, never add or remove words, never change " +
        "words that are already correct, and keep punctuation as it is. Reply with the lines " +
        "only, numbered exactly as given. If a line is already correct, copy it unchanged."

    /** Returns how many lines were corrected. */
    suspend fun run(
        context: Context,
        lecture: Lecture,
        progress: suspend (done: Int, total: Int) -> Unit,
    ): Int {
        val dir = LectureRepository.dir(context)
        val file = TranscriptFixes.file(dir, lecture.id)
        val lines = LectureRepository.loadLines(lecture, applyFixes = true)
        if (lines.isEmpty()) return 0

        val saved = TranscriptFixes.read(file)
        val fixes = LinkedHashMap<Long, String>(saved?.fixes ?: emptyMap())
        var i = (saved?.done ?: 0).coerceIn(0, lines.size)
        val subject = lecture.subject.ifBlank { "unknown" }

        while (i < lines.size) {
            currentCoroutineContext().ensureActive()
            // Don't compete with a recording for the processor.
            while (RecordingSession.state.value.state != RecState.Idle) {
                progress(i, lines.size)
                delay(5_000)
            }
            progress(i, lines.size)

            val end = minOf(i + BATCH, lines.size)
            val batch = lines.subList(i, end)
            val before = lines.subList(maxOf(0, i - CONTEXT_LINES), i)

            val reply = OnDeviceLlm.complete(context, SYSTEM, prompt(subject, before.map { it.text }, batch.map { it.text }))
            val candidates = parseNumbered(reply, batch.size)
            if (candidates != null) {
                for ((k, line) in batch.withIndex()) {
                    val accepted = accept(line.text, candidates[k])
                    if (accepted != null) fixes[line.startMs] = accepted
                }
            }

            i = end
            TranscriptFixes.write(file, FixState(i, fixes))
        }
        progress(lines.size, lines.size)
        return fixes.size
    }

    private fun prompt(subject: String, before: List<String>, batch: List<String>): String {
        val context = if (before.isEmpty()) "" else
            "Earlier lines, for context only (do not output them):\n" +
                before.joinToString("\n") + "\n\n"
        return "Lecture subject: $subject\n\n" + context +
            "Lines to check:\n" +
            batch.withIndex().joinToString("\n") { (k, text) -> "${k + 1}. $text" }
    }

    /** The model's numbered reply as a list, or null unless every line came back. */
    internal fun parseNumbered(reply: String, count: Int): List<String>? {
        val pattern = Regex("^\\s*(\\d+)[.)]\\s*(.*)$")
        val found = HashMap<Int, String>()
        for (line in reply.lines()) {
            val m = pattern.matchEntire(line) ?: continue
            found[m.groupValues[1].toInt()] = m.groupValues[2].trim()
        }
        if ((1..count).any { it !in found }) return null
        return (1..count).map { found.getValue(it) }
    }

    /**
     * Returns the corrected line if the suggestion is a safe, small fix; otherwise null.
     * Casing and punctuation of the original are kept around any replaced word.
     */
    internal fun accept(original: String, candidate: String): String? {
        val a = original.trim().split(' ').filter { it.isNotEmpty() }
        val b = candidate.trim().split(' ').filter { it.isNotEmpty() }
        if (a.isEmpty() || a.size != b.size) return null

        var changed = 0
        val out = ArrayList<String>(a.size)
        for (k in a.indices) {
            val x = core(a[k])
            val y = core(b[k])
            if (x == y) {
                out.add(a[k])
                continue
            }
            if (x.isEmpty() || y.isEmpty()) return null
            if (x.any { it.isDigit() } || y.any { it.isDigit() }) return null
            // A mishearing looks like the word it replaces.
            if (distance(x, y) > maxOf(2, x.length / 2)) return null
            changed++
            out.add(rewrap(a[k], b[k]))
        }
        if (changed == 0 || changed > 3) return null
        return out.joinToString(" ")
    }

    /** Lower-case letters, digits and apostrophes only. */
    private fun core(word: String) =
        word.lowercase().filter { it.isLetterOrDigit() || it == '\'' }

    /** The new word, wearing the old word's capital letter and punctuation. */
    private fun rewrap(old: String, new: String): String {
        val prefix = old.takeWhile { !it.isLetterOrDigit() }
        val suffix = old.takeLastWhile { !it.isLetterOrDigit() }
        var body = new.trim { !it.isLetterOrDigit() }
        val oldBody = old.trim { !it.isLetterOrDigit() }
        if (oldBody.firstOrNull()?.isUpperCase() == true && body.firstOrNull()?.isLowerCase() == true) {
            body = body.replaceFirstChar { it.uppercase() }
        }
        return prefix + body + suffix
    }

    /** The number of single-letter edits needed to turn one word into the other. */
    internal fun distance(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val current = IntArray(b.length + 1)
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }
}
