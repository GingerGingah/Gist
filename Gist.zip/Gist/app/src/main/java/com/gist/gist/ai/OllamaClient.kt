package com.gist.gist.ai

import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import kotlin.concurrent.thread
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** The server couldn't be reached at all (off, asleep, or Tailscale not connected). */
class ServerUnreachableException(message: String, cause: Throwable? = null) :
    IOException(message, cause)

class ModelMissingException(model: String) :
    IOException("The model \"$model\" isn't installed on your server. Run: ollama pull $model")

/** A small client for Ollama's HTTP API, using only what Android already provides. */
class OllamaClient(baseUrl: String, private val model: String) {

    private val base = baseUrl.trimEnd('/')

    /** Names of the models installed on the server. Also a good "is it working?" test. */
    suspend fun listModels(): List<String> {
        val conn = open("/api/tags", "GET", connectMs = 6_000, readMs = 10_000)
        return blocking(conn) {
            try {
                check200(conn)
                val body = conn.inputStream.bufferedReader().readText()
                val arr = JSONObject(body).getJSONArray("models")
                (0 until arr.length()).map { arr.getJSONObject(it).getString("name") }
            } finally {
                conn.disconnect()
            }
        }
    }

    /** Sends one question and returns the full answer. [onText] receives it as it grows. */
    suspend fun chat(
        system: String,
        user: String,
        numCtx: Int = 4096,
        /** Stops the answer after this many tokens (0 = no limit), so a loop can't run on. */
        maxTokens: Int = 0,
        onText: (String) -> Unit = {},
    ): String {
        val options = JSONObject()
            .put("num_ctx", numCtx)
            .put("temperature", 0.2)
            .put("repeat_penalty", 1.1)
        if (maxTokens > 0) options.put("num_predict", maxTokens)
        val payload = JSONObject()
            .put("model", model)
            .put("stream", true)
            .put("keep_alive", "15m")
            .put("options", options)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )

        val conn = open("/api/chat", "POST", connectMs = 8_000, readMs = 300_000)
        return blocking(conn) {
            try {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(payload.toString().toByteArray()) }
                check200(conn)

                val out = StringBuilder()
                conn.inputStream.bufferedReader().useLines { lines ->
                    for (line in lines) {
                        if (line.isBlank()) continue
                        val json = JSONObject(line)
                        val error = json.optString("error")
                        if (error.isNotEmpty()) throw IOException(error)
                        val piece = json.optJSONObject("message")?.optString("content").orEmpty()
                        if (piece.isNotEmpty()) {
                            out.append(piece)
                            onText(out.toString())
                        }
                        if (json.optBoolean("done")) break
                    }
                }
                out.toString()
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun open(path: String, method: String, connectMs: Int, readMs: Int): HttpURLConnection {
        val conn = URL(base + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = connectMs
        conn.readTimeout = readMs
        return conn
    }

    private fun check200(conn: HttpURLConnection) {
        val code = conn.responseCode
        if (code == 200) return
        val body = try {
            conn.errorStream?.bufferedReader()?.readText().orEmpty()
        } catch (e: IOException) {
            ""
        }
        if (code == 404 && body.contains("not found", ignoreCase = true)) {
            throw ModelMissingException(model)
        }
        throw IOException("The server answered $code. ${body.take(200)}")
    }

    /**
     * Runs the blocking network call on its own thread so the coroutine can be cancelled
     * at any moment: cancelling closes the connection, which stops the call straight away.
     */
    private suspend fun <T> blocking(conn: HttpURLConnection, block: () -> T): T =
        suspendCancellableCoroutine { cont ->
            thread(name = "ollama-request", isDaemon = true) {
                try {
                    cont.resume(block())
                } catch (t: Throwable) {
                    val mapped = when (t) {
                        is ConnectException,
                        is UnknownHostException,
                        is NoRouteToHostException,
                        is SocketTimeoutException -> ServerUnreachableException(
                            "Couldn't reach your server. Is Tailscale connected and the server on?", t
                        )
                        else -> t
                    }
                    cont.resumeWithException(mapped)
                }
            }
            cont.invokeOnCancellation { conn.disconnect() }
        }
}
