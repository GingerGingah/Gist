package com.gist.gist.notes

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.gist.gist.MainActivity
import com.gist.gist.R
import com.gist.gist.ai.DeviceBackend
import com.gist.gist.ai.LlmBackend
import com.gist.gist.ai.OllamaClient
import com.gist.gist.ai.OnDeviceLlm
import com.gist.gist.ai.ServerBackend
import com.gist.gist.ai.ServerUnreachableException
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.settings.AppSettings
import kotlinx.coroutines.CancellationException

/** Writes the notes for one or several lectures, in the background and even with the app closed. */
class NotesWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    /** Thrown to stop one lecture when the user cancels it, without stopping the rest. */
    private class Skipped : Exception()

    override suspend fun doWork(): Result {
        val ids = inputData.getStringArray(KEY_IDS)?.toList()
            ?: listOfNotNull(inputData.getString(KEY_ID))
        if (ids.isEmpty()) return Result.failure()
        val settings = AppSettings.state.value
        val app = applicationContext

        val backend: LlmBackend = when {
            NotesManager.runsOffline(app) -> DeviceBackend(app)
            settings.configured -> ServerBackend(
                OllamaClient(AppSettings.baseUrl(settings.serverUrl), settings.model),
                settings.model,
            )
            else -> {
                val reason = if (settings.offlineNotes) "The offline AI isn't installed yet. Download it in Settings."
                else "Add your server address in Settings first."
                ids.forEach { NotesManager.set(it, JobState(JobKind.Failed, message = reason)) }
                return Result.failure()
            }
        }

        var retry = false
        try {
            for ((n, id) in ids.withIndex()) {
                if (!NotesManager.isWanted(id)) continue

                val lecture = LectureRepository.find(app, id)
                if (lecture == null || NotesStore.load(LectureRepository.dir(app), id) != null) {
                    NotesManager.set(id, null)
                    continue
                }

                val prefix = if (ids.size > 1) "Lecture ${n + 1} of ${ids.size}: " else ""
                tryForeground(prefix + "Getting started…", 0, 0)
                try {
                    NotesGenerator.generate(app, lecture, backend) { done, total, stage ->
                        if (!NotesManager.isWanted(id)) throw Skipped()
                        NotesManager.set(id, JobState(JobKind.Working, done, total, stage))
                        tryForeground(prefix + stage, done, total)
                    }
                    NotesManager.set(id, null)
                    NotesNotifier.done(app, lecture)
                } catch (e: Skipped) {
                    // Cancelled from the screen; its state is already cleared.
                } catch (e: ServerUnreachableException) {
                    NotesManager.set(id, JobState(JobKind.WaitingForServer, message = e.message))
                    retry = true
                    break
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    NotesManager.set(
                        id, JobState(JobKind.Failed, message = e.message ?: "Something went wrong.")
                    )
                }
            }
        } finally {
            if (backend.onThisPhone) OnDeviceLlm.release()
        }
        // On a retry, lectures that already have notes are skipped and the rest carry on.
        return if (retry) Result.retry() else Result.success()
    }

    private suspend fun tryForeground(text: String, done: Int, total: Int) {
        try {
            setForeground(
                ForegroundInfo(
                    NotesNotifier.PROGRESS_ID,
                    NotesNotifier.progress(applicationContext, "Gist is writing notes", text, done, total),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
                )
            )
        } catch (e: Exception) {
            // Android doesn't always allow this when started from the background. The job
            // still runs, and carries on from the last finished part if it is stopped.
        }
    }

    companion object {
        const val KEY_ID = "lecture_id"
        const val KEY_IDS = "lecture_ids"
    }
}

object NotesNotifier {
    const val PROGRESS_ID = 2
    const val FIX_ID = 3
    private const val CHANNEL_PROGRESS = "notes_progress"
    private const val CHANNEL_DONE = "notes_done"

    private fun ensureChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROGRESS, "Background work", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DONE, "Notes ready", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(context: Context) = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun progress(context: Context, title: String, text: String, done: Int, total: Int): Notification {
        ensureChannels(context)
        return NotificationCompat.Builder(context, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(total, done, total == 0)
            .setContentIntent(openApp(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    fun done(context: Context, lecture: Lecture) {
        ensureChannels(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Notes are ready")
            .setContentText(lecture.title)
            .setContentIntent(openApp(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(lecture.id.hashCode(), notification)
        } catch (e: SecurityException) {
            // Notifications are switched off for the app; the notes are still saved.
        }
    }
}
