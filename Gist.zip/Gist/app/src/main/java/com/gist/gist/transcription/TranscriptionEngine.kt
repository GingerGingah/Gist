package com.gist.gist.transcription

import com.gist.gist.data.Mark
import com.gist.gist.recording.RecordingSession
import com.gist.gist.text.VocabularyFixer
import com.gist.gist.text.cleanSpoken
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.SpeechSegment
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File

/**
 * Turns the live microphone frames into text, fully on the phone.
 *
 * Voice detection (Silero) cuts the audio at natural pauses; each spoken stretch is then
 * transcribed by Whisper and appended to the transcript files and to [RecordingSession].
 * Two files are written: a readable .txt, and a .jsonl with exact timings that the lecture
 * view uses to highlight each letter as it is spoken.
 * This is the only file that talks to the speech library.
 */
class TranscriptionEngine(
    private val modelDir: File,
    private val transcriptFile: File,
    private val timingFile: File,
    /** The speaker model, or null to skip telling voices apart. */
    private val speakerModel: File? = null,
    private val speakerSensitivity: Float = 0.5f,
    /** The user's subject terms, used to fix mis-heard words as they are transcribed. */
    vocabulary: String = "",
    /** A pause this long ends a sentence. */
    private val pauseSeconds: Float = 0.8f,
) {
    private val fixer = VocabularyFixer(vocabulary)

    private val inbox = Channel<ShortArray>(Channel.UNLIMITED)
    private val segments = Channel<SpeechSegment>(Channel.UNLIMITED)
    private var collector: Job? = null
    private var pipeline: Job? = null

    private val text = StringBuilder()
    private var lastEndMs = 0L
    private var writer: BufferedWriter? = null
    private var timingWriter: BufferedWriter? = null
    private var detector: SpeakerDetector? = null
    private var lastSpeaker = -1

    fun start(scope: CoroutineScope) {
        // Subscribe immediately, so no audio is missed while the models are still loading.
        collector = scope.launch(Dispatchers.Default, start = CoroutineStart.UNDISPATCHED) {
            RecordingSession.frames.collect { inbox.trySend(it) }
        }
        pipeline = scope.launch(Dispatchers.Default) { run() }
    }

    /** Call after the microphone has stopped: transcribes whatever is left, then closes up. */
    suspend fun finish() {
        collector?.cancelAndJoin()
        inbox.close()
        pipeline?.join()
    }

    fun cancel() {
        collector?.cancel()
        inbox.close()
        pipeline?.cancel()
    }

    private suspend fun run() = coroutineScope {
        var vadToRelease: Vad? = null
        var recognizerToRelease: OfflineRecognizer? = null
        try {
            writer = transcriptFile.bufferedWriter()
            timingWriter = timingFile.bufferedWriter()
            val vad = Vad(config = vadConfig())
            vadToRelease = vad
            detector = createDetector()
            val recognizer = OfflineRecognizer(config = recognizerConfig())
            recognizerToRelease = recognizer

            RecordingSession.update { it.copy(transcribing = true) }
            val decoder = launch { decodeLoop(recognizer) }
            vadLoop(vad)
            decoder.join()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            val reason = t.message ?: t.javaClass.simpleName
            RecordingSession.update {
                it.copy(error = "Live transcription stopped ($reason). Audio is still being saved.")
            }
        } finally {
            collector?.cancel()
            inbox.close()
            recognizerToRelease?.release()
            vadToRelease?.release()
            detector?.release()
            try {
                writer?.close()
                timingWriter?.close()
            } catch (e: Exception) {
                // Nothing more to do.
            }
            RecordingSession.update { it.copy(transcribing = false) }
        }
    }

    private suspend fun vadLoop(vad: Vad) {
        for (frame in inbox) {
            val floats = FloatArray(frame.size) { frame[it] / 32768f }
            vad.acceptWaveform(floats)
            drain(vad)
        }
        vad.flush()
        drain(vad)
        segments.close()
    }

    private fun drain(vad: Vad) {
        while (!vad.empty()) {
            segments.trySend(vad.front())
            vad.pop()
        }
    }

    private suspend fun decodeLoop(recognizer: OfflineRecognizer) {
        for (segment in segments) {
            try {
                val stream = recognizer.createStream()
                try {
                    stream.acceptWaveform(segment.samples, SAMPLE_RATE)
                    recognizer.decode(stream)
                    val result = recognizer.getResult(stream)
                    val raw = result.text.trim().replace(Regex("\\s+"), " ")
                    // Drop sound labels and stuck loops, then swap in the user's own terms.
                    val spoken = fixer.fix(cleanSpoken(raw)).first
                    if (spoken.isNotEmpty()) {
                        val lengthMs = segment.samples.size * 1000L / SAMPLE_RATE
                        // The only place that reads the model's own token timings. If a build
                        // error points at the next line, delete it and use "null" instead.
                        val marks = if (spoken == raw) {
                            realMarks(result.tokens.toList(), result.timestamps.toList(), spoken, lengthMs)
                        } else {
                            null   // the text was tidied, so the model's own timings no longer line up
                        }
                        val speaker = detector?.identify(segment.samples, SAMPLE_RATE, lengthMs) ?: 0
                        append(segment.start, segment.samples.size, spoken, marks, speaker)
                    }
                } finally {
                    stream.release()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Skip a segment that fails rather than losing the rest of the lecture.
            }
        }
    }

    /** Whisper sometimes labels silence or noise, e.g. "[BLANK_AUDIO]" or "(music)". */
    private fun isNoiseTag(s: String) = Regex("^[\\[(].*[\\])]$").matches(s)

    /**
     * Turns the model's per-token times into timing points, but only when they look genuine
     * (same count, increasing, and the tokens spell exactly the text we kept). Otherwise null,
     * and the lecture view estimates timing instead.
     */
    private fun realMarks(
        tokens: List<String>,
        stamps: List<Float>,
        spoken: String,
        lengthMs: Long,
    ): List<Mark>? {
        if (tokens.isEmpty() || stamps.size != tokens.size) return null
        if (stamps.last() <= stamps.first()) return null
        if (stamps.zipWithNext().any { (a, b) -> b < a }) return null
        if (stamps.last() * 1000f > lengthMs * 1.5f) return null

        val raw = StringBuilder()
        val starts = ArrayList<Int>()
        for (t in tokens) {
            starts.add(raw.length)
            raw.append(t)
        }
        val rawText = raw.toString()
        if (rawText.trim() != spoken) return null
        val lead = rawText.length - rawText.trimStart().length

        return tokens.indices.map { i ->
            Mark((starts[i] - lead).coerceAtLeast(0), (stamps[i] * 1000f).toInt())
        }
    }

    /** Starts the speaker model if it was asked for; a problem here never stops transcription. */
    private fun createDetector(): SpeakerDetector? {
        val model = speakerModel ?: return null
        return try {
            SpeakerDetector(model, speakerSensitivity)
        } catch (e: Throwable) {
            RecordingSession.update {
                it.copy(error = "Speaker detection couldn't start, so voices won't be told apart.")
            }
            null
        }
    }

    private fun append(
        startSample: Int,
        length: Int,
        spoken: String,
        marks: List<Mark>?,
        speaker: Int,
    ) {
        val startMs = startSample * 1000L / SAMPLE_RATE
        val endMs = startMs + length * 1000L / SAMPLE_RATE
        val gapMs = startMs - lastEndMs
        lastEndMs = endMs

        writer?.apply {
            write("[${stamp(startMs)}] $spoken\n")
            flush()
        }

        val json = JSONObject().put("s", startMs).put("e", endMs).put("t", spoken)
        if (detector != null) json.put("p", speaker)
        if (marks != null) {
            json.put("m", JSONArray(marks.map { JSONArray(listOf(it.charIndex, it.offsetMs)) }))
        }
        timingWriter?.apply {
            write(json.toString())
            write("\n")
            flush()
        }

        // Once a second voice has been heard, label who is speaking on the live screen.
        val labelled = (detector?.speakerCount ?: 0) > 1
        val changed = speaker != lastSpeaker
        if (text.isNotEmpty()) {
            text.append(if (gapMs > PARAGRAPH_GAP_MS || (labelled && changed)) "\n\n" else " ")
        }
        if (labelled && changed) text.append("Speaker ${speaker + 1}: ")
        lastSpeaker = speaker
        text.append(spoken)
        val snapshot = text.toString()
        RecordingSession.update { it.copy(transcript = snapshot) }
    }

    private fun stamp(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    private fun path(name: String) = File(modelDir, name).absolutePath

    private fun vadConfig() = VadModelConfig(
        sileroVadModelConfig = SileroVadModelConfig(
            model = path("silero_vad.onnx"),
            threshold = 0.5f,
            // A pause this long ends a stretch of speech: roughly a sentence (a setting).
            minSilenceDuration = pauseSeconds,
            // Shorter blips are ignored; they are usually a cough or noise, not words.
            minSpeechDuration = 0.4f,
            windowSize = 512,
            // Whisper handles up to 30 s at once, so cut long runs of speech at 20 s.
            maxSpeechDuration = 20f,
        ),
        sampleRate = SAMPLE_RATE,
        numThreads = 1,
        provider = "cpu",
    )

    private fun recognizerConfig() = OfflineRecognizerConfig(
        featConfig = FeatureConfig(sampleRate = SAMPLE_RATE, featureDim = 80),
        modelConfig = OfflineModelConfig(
            whisper = OfflineWhisperModelConfig(
                encoder = path("small.en-encoder.int8.onnx"),
                decoder = path("small.en-decoder.int8.onnx"),
                language = "en",
                task = "transcribe",
            ),
            tokens = path("small.en-tokens.txt"),
            numThreads = NUM_THREADS,
            provider = "cpu",
            modelType = "whisper",
        ),
        decodingMethod = "greedy_search",
    )

    private companion object {
        const val SAMPLE_RATE = RecordingSession.SAMPLE_RATE

        /** Threads for Whisper. Raise or lower this after testing speed and battery on the Fold. */
        const val NUM_THREADS = 4

        /** A pause longer than this starts a new paragraph in the on-screen transcript. */
        const val PARAGRAPH_GAP_MS = 2_500L
    }
}
