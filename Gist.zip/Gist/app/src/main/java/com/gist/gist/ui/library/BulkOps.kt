package com.gist.gist.ui.library

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.notes.NotesStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.OutputStream

/** Sharing and saving several lectures at once. Files are handed over as files, not text. */
object BulkOps {

    private fun sharedDir(context: Context): File =
        File(context.cacheDir, "shared").apply { mkdirs() }

    /** Share one text file per lecture (transcript, with speaker names if there were several). */
    suspend fun shareTranscripts(context: Context, chosen: List<Lecture>) {
        val files = withContext(Dispatchers.IO) {
            sharedDir(context).listFiles()?.forEach { it.delete() }
            chosen.map { lecture ->
                val lines = LectureRepository.loadLines(lecture)
                File(sharedDir(context), Export.baseName(lecture) + ".txt")
                    .also { it.writeText(Export.transcriptText(lecture, lines)) }
            }
        }
        send(context, files, "text/plain", "Share transcripts")
    }

    /** Share one text file per lecture that has notes. Returns how many lectures had notes. */
    suspend fun shareNotes(context: Context, chosen: List<Lecture>): Int {
        val files = withContext(Dispatchers.IO) {
            sharedDir(context).listFiles()?.forEach { it.delete() }
            val dir = LectureRepository.dir(context)
            chosen.mapNotNull { lecture ->
                val notes = NotesStore.load(dir, lecture.id) ?: return@mapNotNull null
                File(sharedDir(context), Export.baseName(lecture) + "_notes.txt")
                    .also { it.writeText(Export.notesText(lecture, notes)) }
            }
        }
        if (files.isNotEmpty()) send(context, files, "text/plain", "Share notes")
        return files.size
    }

    fun shareAudio(context: Context, chosen: List<Lecture>) {
        send(context, chosen.map { it.audioFile }, "audio/wav", "Share audio")
    }

    private fun send(context: Context, files: List<File>, mime: String, title: String) {
        val uris = ArrayList(
            files.map { FileProvider.getUriForFile(context, "${context.packageName}.files", it) }
        )
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.type = mime
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, title))
    }

    /**
     * Copies each lecture's audio, transcript and notes into a folder the user picked.
     * Returns how many lectures were saved completely.
     */
    suspend fun saveToFolder(
        context: Context,
        tree: Uri,
        chosen: List<Lecture>,
        onProgress: (done: Int, total: Int) -> Unit,
    ): Int = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        val dir = LectureRepository.dir(context)
        var saved = 0
        for ((i, lecture) in chosen.withIndex()) {
            onProgress(i, chosen.size)
            try {
                val base = Export.baseName(lecture)
                writeFile(resolver, parent, "audio/x-wav", "$base.wav") { out ->
                    lecture.audioFile.inputStream().use { it.copyTo(out) }
                }
                val lines = LectureRepository.loadLines(lecture)
                writeFile(resolver, parent, "text/plain", "$base.txt") {
                    it.write(Export.transcriptText(lecture, lines).toByteArray())
                }
                NotesStore.load(dir, lecture.id)?.let { notes ->
                    writeFile(resolver, parent, "text/plain", "${base}_notes.txt") {
                        it.write(Export.notesText(lecture, notes).toByteArray())
                    }
                }
                saved++
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Skip this one and carry on with the rest.
            }
        }
        saved
    }

    private fun writeFile(
        resolver: ContentResolver,
        parent: Uri,
        mime: String,
        name: String,
        write: (OutputStream) -> Unit,
    ) {
        val document = DocumentsContract.createDocument(resolver, parent, mime, name)
            ?: throw IOException("Couldn't create $name")
        val out = resolver.openOutputStream(document) ?: throw IOException("Couldn't open $name")
        out.use(write)
    }
}
