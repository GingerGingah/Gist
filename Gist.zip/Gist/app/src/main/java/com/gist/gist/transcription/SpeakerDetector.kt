package com.gist.gist.transcription

import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractor
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractorConfig
import java.io.File
import kotlin.math.sqrt

/**
 * Works out who is speaking, one spoken stretch at a time.
 *
 * Each stretch is turned into a "voiceprint" (a list of numbers describing the voice). It is
 * compared with the voices heard so far: a close match joins that speaker, a clearly different
 * voice becomes a new speaker, and anything unsure stays with whoever spoke last, so one
 * person isn't split in two by a cough or a noisy moment.
 *
 * This is the only file that talks to the speaker part of the speech library.
 */
class SpeakerDetector(modelFile: File, sensitivity: Float) {

    private val extractor = SpeakerEmbeddingExtractor(
        config = SpeakerEmbeddingExtractorConfig(
            model = modelFile.absolutePath,
            numThreads = 1,
            debug = false,
            provider = "cpu",
        )
    )

    private val centroids = ArrayList<FloatArray>()
    private val counts = ArrayList<Int>()
    private var previous = 0

    /** Higher sensitivity needs a closer match to join a speaker, so more speakers are found. */
    private val match = 0.35f + 0.3f * sensitivity.coerceIn(0f, 1f)
    private val unsure = match - 0.15f

    val speakerCount: Int get() = centroids.size

    /** The speaker (0 for the first voice heard) for this stretch of 16 kHz audio. */
    fun identify(samples: FloatArray, sampleRate: Int, durationMs: Long): Int {
        // Very short stretches ("yes", "okay") say too little about the voice.
        if (durationMs < MIN_MS) return previous
        val voice = embed(samples, sampleRate) ?: return previous

        if (centroids.isEmpty()) {
            centroids.add(voice)
            counts.add(1)
            previous = 0
            return 0
        }

        var best = 0
        var bestSimilarity = -1f
        for (i in centroids.indices) {
            val similarity = dot(centroids[i], voice)
            if (similarity > bestSimilarity) {
                bestSimilarity = similarity
                best = i
            }
        }

        val chosen = when {
            bestSimilarity >= match -> {
                learn(best, voice)
                best
            }
            bestSimilarity >= unsure -> previous
            durationMs >= NEW_SPEAKER_MIN_MS && centroids.size < MAX_SPEAKERS -> {
                centroids.add(voice)
                counts.add(1)
                centroids.size - 1
            }
            else -> best
        }
        previous = chosen
        return chosen
    }

    fun release() {
        try {
            extractor.release()
        } catch (e: Exception) {
            // Nothing more to do.
        }
    }

    private fun embed(samples: FloatArray, sampleRate: Int): FloatArray? {
        val stream = extractor.createStream()
        return try {
            stream.acceptWaveform(samples, sampleRate)
            stream.inputFinished()
            if (extractor.isReady(stream)) normalize(extractor.compute(stream)) else null
        } finally {
            stream.release()
        }
    }

    /** Nudges a speaker's voiceprint towards this sample, so it adapts to the room. */
    private fun learn(index: Int, voice: FloatArray) {
        val centroid = centroids[index]
        val weight = counts[index].toFloat()
        for (i in centroid.indices) centroid[i] = centroid[i] * weight + voice[i]
        centroids[index] = normalize(centroid)
        counts[index] = minOf(counts[index] + 1, 30)
    }

    private fun dot(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) sum += a[i] * b[i]
        return sum
    }

    private fun normalize(v: FloatArray): FloatArray {
        var sum = 0f
        for (x in v) sum += x * x
        val norm = sqrt(sum).coerceAtLeast(1e-6f)
        return FloatArray(v.size) { v[it] / norm }
    }

    private companion object {
        const val MIN_MS = 1_000L
        const val NEW_SPEAKER_MIN_MS = 1_500L
        const val MAX_SPEAKERS = 6
    }
}
