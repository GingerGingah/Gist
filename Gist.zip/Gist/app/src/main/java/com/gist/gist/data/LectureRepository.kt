package com.gist.gist.data

import android.content.Context
import com.gist.gist.notes.NotesStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Reads lectures from the recordings folder. The .wav is the source of truth, so a lecture
 * survives even if its info file or transcript is missing (for example after a crash).
 */
object LectureRepository {

    private val stampRegex = Regex("""lecture_(\d{8}_\d{6})""")
    private val lineRegex = Regex("""^\[(\d+):(\d{2})(?::(\d{2}))?\]\s*(.*)$""")

    /** 16 kHz, 16-bit, mono = 32 bytes of audio per millisecond. */
    private const val BYTES_PER_MS = 32L
    private const val HEADER_BYTES = 44L

    /** Rough speaking pace, used only for older lectures that have no saved timings. */
    private const val MS_PER_CHAR = 70L

    fun dir(context: Context): File = File(context.filesDir, "recordings")

    suspend fun loadAll(context: Context, activeAudioName: String?): List<Lecture> =
        withContext(Dispatchers.IO) {
            val files = dir(context).listFiles() ?: return@withContext emptyList()
            files
                .filter { it.extension == "wav" && it.name != activeAudioName }
                .mapNotNull { build(it) }
                .sortedByDescending { it.startedAt }
        }

    /** Finds one lecture by id (used by the notes job). */
    fun find(context: Context, id: String): Lecture? {
        val wav = File(dir(context), "$id.wav")
        return if (wav.exists()) build(wav) else null
    }

    /** Total size of everything saved by the app, in bytes. */
    suspend fun storageBytes(context: Context): Long = withContext(Dispatchers.IO) {
        dir(context).listFiles()?.sumOf { it.length() } ?: 0L
    }

    suspend fun loadLines(lecture: Lecture, applyFixes: Boolean = true): List<TranscriptLine> =
        withContext(Dispatchers.IO) {
            readTranscript(
                lecture.transcriptFile,
                lecture.timingFile,
                if (applyFixes) TranscriptFixes.read(TranscriptFixes.file(lecture.metaFile.parentFile ?: return@withContext emptyList(), lecture.id)) else null,
            )
        }

    fun rename(lecture: Lecture, subject: String) {
        val json = try {
            JSONObject(lecture.metaFile.readText())
        } catch (e: Exception) {
            JSONObject()
                .put("audioFile", lecture.audioFile.name)
                .put("startedAt", lecture.startedAt)
        }
        json.put("subject", subject).put("durationMs", lecture.durationMs)
        lecture.metaFile.writeText(json.toString(2))
    }

    fun delete(lecture: Lecture) {
        lecture.audioFile.delete()
        lecture.transcriptFile?.delete()
        lecture.timingFile?.delete()
        lecture.metaFile.delete()
        val folder = lecture.audioFile.parentFile ?: return
        NotesStore.deleteAll(folder, lecture.id)
        TranscriptFixes.file(folder, lecture.id).delete()
    }

    private fun build(wav: File): Lecture? {
        // Under a second of audio is an accidental tap, not a lecture.
        if (wav.length() < HEADER_BYTES + 1_000 * BYTES_PER_MS) return null
        repairWavHeader(wav)

        val base = wav.nameWithoutExtension
        val meta = File(wav.parentFile, "$base.json")
        val txt = File(wav.parentFile, "$base.txt").takeIf { it.exists() }
        val timing = File(wav.parentFile, "$base.jsonl").takeIf { it.exists() }

        var subject = ""
        var startedAt = parseStamp(base) ?: wav.lastModified()
        var bookmarks: List<Long> = emptyList()
        if (meta.exists()) {
            try {
                val json = JSONObject(meta.readText())
                subject = json.optString("subject", "")
                startedAt = json.optLong("startedAt", startedAt)
                json.optJSONArray("bookmarks")?.let { arr ->
                    bookmarks = (0 until arr.length()).map { arr.getLong(it) }
                }
            } catch (e: Exception) {
                // Fall back to what the file name tells us.
            }
        }

        val fixes = TranscriptFixes.read(TranscriptFixes.file(wav.parentFile ?: return null, base))
        val lines = readTranscript(txt, timing, fixes)
        val text = lines.joinToString(" ") { it.text }
        val notes = NotesStore.read(File(wav.parentFile, "$base.notes.json"))
        return Lecture(
            id = base,
            subject = subject,
            startedAt = startedAt,
            durationMs = (wav.length() - HEADER_BYTES) / BYTES_PER_MS,
            audioFile = wav,
            transcriptFile = txt,
            timingFile = timing,
            metaFile = meta,
            text = text,
            bookmarks = bookmarks,
            hasNotes = notes != null,
            notesText = notes?.let { NotesStore.plainText(it) }.orEmpty(),
            speakers = (lines.maxOfOrNull { it.speaker } ?: 0) + 1,
            fixCount = lines.count { it.original != null },
        )
    }

    private fun readTranscript(txt: File?, timing: File?, fixes: FixState? = null): List<TranscriptLine> {
        var lines: List<TranscriptLine> = emptyList()
        if (timing != null) lines = readTiming(timing)
        if (lines.isEmpty() && txt != null) lines = readTxt(txt)
        val corrections = fixes?.fixes ?: return lines
        return lines.map { line ->
            val fixed = corrections[line.startMs]
            if (fixed != null && fixed != line.text) line.withText(fixed) else line
        }
    }

    /** Newer recordings: one JSON object per line with exact start, end and optional marks. */
    private fun readTiming(file: File): List<TranscriptLine> = try {
        file.readLines().mapNotNull { raw ->
            try {
                val j = JSONObject(raw)
                val marks = j.optJSONArray("m")?.let { arr ->
                    (0 until arr.length()).map { i ->
                        val pair = arr.getJSONArray(i)
                        Mark(pair.getInt(0), pair.getInt(1))
                    }
                }
                TranscriptLine(j.getLong("s"), j.getLong("e"), j.getString("t"), marks, j.optInt("p", 0))
            } catch (e: Exception) {
                null // A half-written last line after a crash.
            }
        }
    } catch (e: IOException) {
        emptyList()
    }

    /** Older recordings: only start times (to the second), so the ends are estimated. */
    private fun readTxt(file: File): List<TranscriptLine> {
        val parsed = try {
            file.readLines().mapNotNull { parseLine(it) }
        } catch (e: IOException) {
            return emptyList()
        }
        return parsed.mapIndexed { i, (start, text) ->
            val guess = start + maxOf(500L, text.length * MS_PER_CHAR)
            val nextStart = parsed.getOrNull(i + 1)?.first
            val end = if (nextStart != null && nextStart > start) minOf(guess, nextStart) else guess
            TranscriptLine(start, end, text)
        }
    }

    private fun parseLine(line: String): Pair<Long, String>? {
        val m = lineRegex.matchEntire(line.trim()) ?: return null
        val a = m.groupValues[1].toLong()
        val b = m.groupValues[2].toLong()
        val c = m.groupValues[3]
        val seconds = if (c.isNotEmpty()) a * 3600 + b * 60 + c.toLong() else a * 60 + b
        return Pair(seconds * 1000, m.groupValues[4])
    }

    private fun parseStamp(base: String): Long? {
        val stamp = stampRegex.find(base)?.groupValues?.get(1) ?: return null
        return try {
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).parse(stamp)?.time
        } catch (e: Exception) {
            null
        }
    }

    /**
     * While recording, the header is refreshed every couple of seconds. After a crash it can be
     * a little behind the audio, so fix it before playing the file.
     */
    private fun repairWavHeader(file: File) {
        try {
            RandomAccessFile(file, "rw").use { raf ->
                var dataLen = raf.length() - HEADER_BYTES
                dataLen -= dataLen % 2
                raf.seek(40)
                val stored = Integer.reverseBytes(raf.readInt()).toLong()
                if (stored != dataLen) {
                    raf.seek(4)
                    raf.writeInt(Integer.reverseBytes((36 + dataLen).toInt()))
                    raf.seek(40)
                    raf.writeInt(Integer.reverseBytes(dataLen.toInt()))
                }
            }
        } catch (e: IOException) {
            // Leave the file as it is.
        }
    }
}
