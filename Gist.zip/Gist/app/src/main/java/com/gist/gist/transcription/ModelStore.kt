package com.gist.gist.transcription

import android.app.DownloadManager
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

sealed interface ModelState {
    data object Checking : ModelState
    data object Missing : ModelState
    data class Downloading(
        val progress: Float,
        val doneBytes: Long,
        val totalBytes: Long,
        val waiting: Boolean,
    ) : ModelState
    data object Ready : ModelState
    data class Failed(val message: String) : ModelState
}

/**
 * The "Download prerequisites?" step, for the speech model and the optional extras. Files are
 * fetched by Android's own download manager, so downloads continue in the background, resume
 * after interruptions, and can be limited to Wi-Fi.
 */
object ModelStore {

    class Item(val name: String, val url: String)

    class Pack(
        val id: String,
        val title: String,
        val sizeText: String,
        val approxBytes: Long,
        val subDir: String,
        val items: List<Item>,
    )

    private const val HF_WHISPER =
        "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-small.en/resolve/main/"

    /** Required for live transcription. */
    val speech = Pack(
        id = "speech",
        title = "Speech model",
        sizeText = "about 400 MB",
        approxBytes = 420_000_000L,
        subDir = "models/whisper-small.en",
        items = listOf(
            Item("small.en-encoder.int8.onnx", HF_WHISPER + "small.en-encoder.int8.onnx"),
            Item("small.en-decoder.int8.onnx", HF_WHISPER + "small.en-decoder.int8.onnx"),
            Item("small.en-tokens.txt", HF_WHISPER + "small.en-tokens.txt"),
            Item(
                "silero_vad.onnx",
                "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx",
            ),
        ),
    )

    const val SPEAKER_FILE = "wespeaker_en_voxceleb_resnet34.onnx"

    /** Optional: tells voices apart. */
    val speaker = Pack(
        id = "speaker",
        title = "Speaker model",
        sizeText = "about 26 MB",
        approxBytes = 30_000_000L,
        subDir = "models/speaker",
        items = listOf(
            Item(
                SPEAKER_FILE,
                "https://huggingface.co/csukuangfj/speaker-embedding-models/resolve/main/$SPEAKER_FILE",
            ),
        ),
    )

    const val OFFLINE_FILE = "qwen2.5-1.5b-instruct-q8.task"

    /** Optional: a small language model that runs on the phone (notes, word checking). */
    val offlineAi = Pack(
        id = "offline_ai",
        title = "Offline AI",
        sizeText = "about 1.6 GB",
        approxBytes = 1_700_000_000L,
        subDir = "models/offline-ai",
        items = listOf(
            Item(
                OFFLINE_FILE,
                "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/" +
                    "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.task",
            ),
        ),
    )

    val packs = listOf(speech, speaker, offlineAi)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _states = MutableStateFlow<Map<String, ModelState>>(emptyMap())

    /** State of every pack, by pack id. */
    val states: StateFlow<Map<String, ModelState>> = _states.asStateFlow()

    /** State of the speech model (the one the Record screen asks about). */
    val state: StateFlow<ModelState> = _states
        .map { it[speech.id] ?: ModelState.Checking }
        .stateIn(scope, SharingStarted.Eagerly, ModelState.Checking)

    private val polls = ConcurrentHashMap<String, Job>()

    private fun set(pack: Pack, state: ModelState) {
        _states.update { it + (pack.id to state) }
    }

    fun dir(context: Context, pack: Pack = speech): File {
        val app = context.applicationContext
        return File(app.getExternalFilesDir(null) ?: app.filesDir, pack.subDir)
    }

    fun isReady(context: Context, pack: Pack = speech): Boolean {
        val d = dir(context, pack)
        return File(d, "READY").exists() && pack.items.all { File(d, it.name).length() > 0 }
    }

    /** Call when a screen opens. */
    fun refresh(context: Context) {
        val app = context.applicationContext
        for (pack in packs) {
            val running = polls[pack.id]?.isActive == true
            when {
                isReady(app, pack) -> set(pack, ModelState.Ready)
                savedIds(app, pack).isNotEmpty() -> if (!running) watch(app, pack)
                else -> if (!running) set(pack, ModelState.Missing)
            }
        }
    }

    fun start(context: Context, allowMobileData: Boolean, pack: Pack = speech) {
        val app = context.applicationContext
        if (polls[pack.id]?.isActive == true || isReady(app, pack)) return

        val free = (app.getExternalFilesDir(null) ?: app.filesDir).usableSpace
        if (free < pack.approxBytes + 200_000_000L) {
            set(pack, ModelState.Failed("Not enough free storage. This needs ${pack.sizeText.removePrefix("about ")} free."))
            return
        }

        dir(app, pack).deleteRecursively()
        val network = if (allowMobileData) {
            DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
        } else {
            DownloadManager.Request.NETWORK_WIFI
        }
        val dm = app.getSystemService(DownloadManager::class.java)
        try {
            val ids = pack.items.map { item ->
                val request = DownloadManager.Request(android.net.Uri.parse(item.url))
                    .setTitle("Gist: ${pack.title.lowercase()}")
                    .setDescription(item.name)
                    .setAllowedOverRoaming(false)
                    .setAllowedNetworkTypes(network)
                    .setDestinationInExternalFilesDir(app, null, "${pack.subDir}/${item.name}")
                dm.enqueue(request)
            }
            saveIds(app, pack, ids)
            watch(app, pack)
        } catch (e: Exception) {
            set(pack, ModelState.Failed("Couldn't start the download: ${e.message}"))
        }
    }

    /** Stops a download, or removes an installed pack to free its space. */
    fun cancel(context: Context, pack: Pack = speech) {
        val app = context.applicationContext
        polls[pack.id]?.cancel()
        removeAll(app, pack)
        set(pack, ModelState.Missing)
    }

    private fun watch(app: Context, pack: Pack) {
        polls[pack.id]?.cancel()
        polls[pack.id] = scope.launch {
            val dm = app.getSystemService(DownloadManager::class.java)
            while (isActive) {
                val ids = savedIds(app, pack)
                if (ids.isEmpty()) {
                    set(pack, ModelState.Missing)
                    return@launch
                }

                var done = 0L
                var total = 0L
                var sized = true
                var rows = 0
                var finished = 0
                var waiting = false
                var failureReason = -1

                try {
                    dm.query(DownloadManager.Query().setFilterById(*ids.toLongArray()))?.use { c ->
                        while (c.moveToNext()) {
                            rows++
                            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            val size = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            done += c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            if (size > 0) total += size else sized = false
                            when (status) {
                                DownloadManager.STATUS_SUCCESSFUL -> finished++
                                DownloadManager.STATUS_PAUSED -> waiting = true
                                DownloadManager.STATUS_FAILED ->
                                    failureReason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            }
                        }
                    }
                } catch (e: Exception) {
                    removeAll(app, pack)
                    set(pack, ModelState.Failed("Couldn't check the download: ${e.message}"))
                    return@launch
                }

                when {
                    failureReason >= 0 -> {
                        removeAll(app, pack)
                        set(
                            pack,
                            ModelState.Failed(
                                "The download failed (error $failureReason). Check your connection and try again."
                            ),
                        )
                        return@launch
                    }
                    rows < ids.size -> {
                        removeAll(app, pack)
                        set(pack, ModelState.Failed("The download was cancelled."))
                        return@launch
                    }
                    finished == ids.size -> {
                        File(dir(app, pack), "READY").writeText("ok")
                        saveIds(app, pack, emptyList())
                        set(pack, ModelState.Ready)
                        return@launch
                    }
                }

                val knownTotal = if (sized) total else 0L
                set(
                    pack,
                    ModelState.Downloading(
                        progress = if (knownTotal > 0) (done.toFloat() / knownTotal).coerceIn(0f, 1f) else 0f,
                        doneBytes = done,
                        totalBytes = knownTotal,
                        waiting = waiting,
                    ),
                )
                delay(500)
            }
        }
    }

    private fun removeAll(app: Context, pack: Pack) {
        val ids = savedIds(app, pack)
        if (ids.isNotEmpty()) {
            app.getSystemService(DownloadManager::class.java).remove(*ids.toLongArray())
        }
        saveIds(app, pack, emptyList())
        dir(app, pack).deleteRecursively()
    }

    private fun prefs(c: Context) = c.getSharedPreferences("model_store", Context.MODE_PRIVATE)

    // The speech pack keeps the original key, so a download in progress from an older
    // version is still recognised.
    private fun key(pack: Pack) = if (pack.id == "speech") "ids" else "ids_${pack.id}"

    private fun savedIds(c: Context, pack: Pack): List<Long> =
        (prefs(c).getString(key(pack), "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    private fun saveIds(c: Context, pack: Pack, ids: List<Long>) {
        prefs(c).edit().putString(key(pack), ids.joinToString(",")).apply()
    }
}
