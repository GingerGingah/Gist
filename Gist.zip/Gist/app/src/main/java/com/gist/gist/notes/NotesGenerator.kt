package com.gist.gist.notes

import android.content.Context
import com.gist.gist.ai.LlmBackend
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.data.TranscriptLine
import com.gist.gist.recording.RecState
import com.gist.gist.recording.RecordingSession
import com.gist.gist.text.cleanMarkdown
import com.gist.gist.ui.formatClock
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

/**
 * Turns a transcript into study notes with a small model, either on your own server or on the
 * phone itself.
 *
 * A small model does far better on short pieces than on a whole lecture, so the transcript is
 * cut into parts, each part gets its own notes, and a final pass writes the overview, key terms
 * and review questions from those notes.
 */
object NotesGenerator {

    private const val MAX_PART_MS = 12 * 60_000L

    private const val SYSTEM = "You are a careful note-taker for university lectures. " +
        "Use only what is in the text you are given. The transcript comes from automatic speech " +
        "recognition, so some words may be wrong; do not guess corrections you are not sure of. " +
        "Do not invent facts, numbers, terms or extra sections (for example no pronunciation guides). " +
        "Write concise Markdown using only headings, bullet points and **bold**. Never use tables, " +
        "code blocks or HTML, and never repeat yourself. Output nothing but the notes, with no " +
        "introduction or closing remarks."

    class Part(val startMs: Long, val endMs: Long, val text: String)

    suspend fun generate(
        context: Context,
        lecture: Lecture,
        backend: LlmBackend,
        progress: suspend (done: Int, total: Int, stage: String) -> Unit,
    ) {
        val dir = LectureRepository.dir(context)
        val lines = LectureRepository.loadLines(lecture)
        if (lines.isEmpty()) throw IllegalStateException("This lecture has no transcript to write notes from.")

        val labelSpeakers = lecture.speakers > 1
        val parts = split(lines, backend.wordsPerPart, labelSpeakers)
        val subject = lecture.subject.ifBlank { "unknown" }

        // Pick up where an interrupted job stopped.
        val sections = ArrayList<NoteSection>()
        for ((i, saved) in NotesStore.loadPartial(dir, lecture.id).withIndex()) {
            if (i < parts.size && parts[i].startMs == saved.startMs) sections.add(saved) else break
        }

        val total = parts.size + 1
        for (i in sections.size until parts.size) {
            currentCoroutineContext().ensureActive()
            waitWhileRecording(backend, i, total, progress)
            progress(i, total, "Part ${i + 1} of ${parts.size}")

            val part = parts[i]
            val marked = lecture.bookmarks.filter { it in part.startMs..part.endMs }
            val reply = backend.chat(SYSTEM, partPrompt(subject, part, marked, labelSpeakers))
            val clean = cleanMarkdown(tidyReply(reply)).ifBlank { "(No notes for this part.)" }
            sections.add(NoteSection(part.startMs, part.endMs, clean))
            NotesStore.savePartial(dir, lecture.id, sections)
        }

        waitWhileRecording(backend, parts.size, total, progress)
        progress(parts.size, total, "Putting it together")
        val finalReply = backend.chat(SYSTEM, finalPrompt(subject, sections, backend.digestChars), bigContext = true)
        val (overview, terms, questions) = parseFinal(cleanMarkdown(tidyReply(finalReply)))

        NotesStore.save(
            dir,
            lecture.id,
            LectureNotes(
                model = backend.label,
                generatedAt = System.currentTimeMillis(),
                overview = overview,
                keyTerms = terms,
                questions = questions,
                sections = sections,
            ),
        )
        NotesStore.clearPartial(dir, lecture.id)
    }

    /** Work on the phone waits for a recording to finish, so the two don't slow each other. */
    private suspend fun waitWhileRecording(
        backend: LlmBackend,
        done: Int,
        total: Int,
        progress: suspend (Int, Int, String) -> Unit,
    ) {
        if (!backend.onThisPhone) return
        while (RecordingSession.state.value.state != RecState.Idle) {
            progress(done, total, "Waiting for your recording to finish")
            delay(5_000)
        }
    }

    fun split(lines: List<TranscriptLine>, maxWords: Int, labelSpeakers: Boolean): List<Part> {
        val parts = ArrayList<Part>()
        val buffer = StringBuilder()
        var start = -1L
        var end = 0L
        var words = 0
        var lastSpeaker = -1

        fun flush() {
            if (buffer.isNotEmpty()) parts.add(Part(start, end, buffer.toString().trim()))
            buffer.clear()
            words = 0
            start = -1L
            lastSpeaker = -1
        }

        for (line in lines) {
            val w = line.text.count { it == ' ' } + 1
            if (start < 0) {
                start = line.startMs
            } else if (words + w > maxWords || line.endMs - start > MAX_PART_MS) {
                flush()
                start = line.startMs
            }
            if (labelSpeakers && line.speaker != lastSpeaker) {
                buffer.append("[Speaker ${line.speaker + 1}] ")
                lastSpeaker = line.speaker
            }
            buffer.append(line.text).append(' ')
            words += w
            end = line.endMs
        }
        flush()
        return parts
    }

    private fun partPrompt(subject: String, part: Part, bookmarks: List<Long>, speakers: Boolean): String {
        val bookmarkNote = if (bookmarks.isEmpty()) "" else
            "The student bookmarked this part (at ${bookmarks.joinToString { formatClock(it) }}) " +
                "as important, so make sure its main points are clear.\n"
        val speakerNote = if (!speakers) "" else
            "Tags like [Speaker 2] show a change of speaker. Speaker 1 is usually the lecturer; " +
                "briefly note questions or comments from anyone else.\n"
        return "Lecture subject: $subject\n" +
            "Part of the lecture: ${formatClock(part.startMs)} to ${formatClock(part.endMs)}\n" +
            bookmarkNote + speakerNote +
            "\nTranscript:\n\"\"\"\n${part.text}\n\"\"\"\n\n" +
            "Write study notes for this part as Markdown. Use short bullet points, put key terms " +
            "in **bold**, and group related points under short bold headings. Do not use tables. " +
            "Keep it under 200 words."
    }

    private fun finalPrompt(subject: String, sections: List<NoteSection>, maxChars: Int): String {
        var digest = sections.joinToString("\n\n") {
            "### ${formatClock(it.startMs)}–${formatClock(it.endMs)}\n${it.markdown}"
        }
        if (digest.length > maxChars) {
            val each = maxChars / sections.size
            digest = sections.joinToString("\n\n") {
                "### ${formatClock(it.startMs)}–${formatClock(it.endMs)}\n${it.markdown.take(each)}"
            }
        }
        return "Below are notes from consecutive parts of a lecture on \"$subject\".\n\n$digest\n\n" +
            "Using only these notes, write the following in Markdown, with exactly these three headings:\n\n" +
            "## Overview\nThree to five sentences summarising the lecture.\n\n" +
            "## Key terms\nA bullet list of the important terms with a short definition each, " +
            "like: - **Term**: definition.\n\n" +
            "## Review questions\nFive numbered questions that would help the student test their understanding.\n\n" +
            "Do not add any other headings and do not use tables."
    }

    /** Removes the chattiness small models add: code fences and "Here are the notes:". */
    private fun tidyReply(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```")) {
            text = text.removePrefix("```markdown").removePrefix("```md").removePrefix("```").trim()
            text = text.removeSuffix("```").trim()
        }
        val lines = text.lines().toMutableList()
        if (lines.isNotEmpty() &&
            Regex("(?i)^(here (are|is)|sure|okay|certainly)\\b.*").matches(lines.first().trim())
        ) {
            lines.removeAt(0)
        }
        return lines.joinToString("\n").trim()
    }

    /** 0 = overview, 1 = key terms, 2 = questions, -1 = some other heading, null = not a heading. */
    private fun headingKind(line: String): Int? {
        val t = line.trim()
        val isHeading = t.startsWith("#") ||
            Regex("""^\*\*[^*]{1,30}\*\*:?$""").matches(t) ||
            Regex("""^[A-Za-z ]{3,30}:$""").matches(t)
        if (!isHeading) return null
        val bare = t.trimStart('#').trim().trim('*').trim(':').trim().lowercase()
        return when {
            bare.startsWith("overview") || bare.startsWith("summary") -> 0
            bare.contains("term") || bare.startsWith("key concept") -> 1
            bare.contains("question") -> 2
            else -> -1
        }
    }

    private fun parseFinal(markdown: String): Triple<String, String, String> {
        val overview = StringBuilder()
        val terms = StringBuilder()
        val questions = StringBuilder()
        val sections = listOf(overview, terms, questions)
        var current: StringBuilder? = null
        for (line in markdown.lines()) {
            val kind = headingKind(line)
            // A line like "Examples:" is only dropped if it is a real heading (starts with #).
            if (kind != null && (kind >= 0 || line.trim().startsWith("#"))) {
                if (kind >= 0) current = sections[kind]
                continue
            }
            current?.appendLine(line)
        }
        if (overview.isBlank() && terms.isBlank() && questions.isBlank()) {
            return Triple(markdown, "", "")
        }
        return Triple(overview.toString().trim(), terms.toString().trim(), questions.toString().trim())
    }
}
