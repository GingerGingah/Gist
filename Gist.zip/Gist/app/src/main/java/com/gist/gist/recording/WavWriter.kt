package com.gist.gist.recording

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Writes 16-bit mono PCM straight to a .wav file as it arrives. The header is re-patched every
 * couple of seconds, so even after a crash or dead battery the file is playable up to that point.
 */
class WavWriter(file: File, private val sampleRate: Int) : Closeable {

    private val raf = RandomAccessFile(file, "rw")
    private var dataBytes = 0L

    init {
        raf.setLength(0)
        raf.write(header(0))
    }

    fun write(samples: ShortArray, count: Int) {
        val bytes = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) bytes.putShort(samples[i])
        raf.write(bytes.array(), 0, count * 2)
        dataBytes += count * 2L
    }

    /** Makes the header match what has been written so far and forces it onto disk. */
    fun patchHeader() {
        val pos = raf.filePointer
        raf.seek(0)
        raf.write(header(dataBytes))
        raf.seek(pos)
        raf.fd.sync()
    }

    override fun close() {
        try {
            patchHeader()
        } finally {
            raf.close()
        }
    }

    private fun header(dataLen: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray(Charsets.US_ASCII))
        b.putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray(Charsets.US_ASCII))
        b.put("fmt ".toByteArray(Charsets.US_ASCII))
        b.putInt(16)
        b.putShort(1.toShort())            // PCM
        b.putShort(1.toShort())            // mono
        b.putInt(sampleRate)
        b.putInt(sampleRate * 2)           // byte rate
        b.putShort(2.toShort())            // block align
        b.putShort(16.toShort())           // bits per sample
        b.put("data".toByteArray(Charsets.US_ASCII))
        b.putInt(dataLen.toInt())
        return b.array()
    }
}
