package com.gist.gist.fixes

import android.content.Context
import android.content.pm.ServiceInfo
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.gist.gist.ai.OnDeviceLlm
import com.gist.gist.data.LectureRepository
import com.gist.gist.notes.JobKind
import com.gist.gist.notes.JobState
import com.gist.gist.notes.NotesNotifier
import com.gist.gist.transcription.ModelStore
import kotlinx.coroutines.CancellationException

/**
 * Checks the words of one or several lectures with the offline AI, in the background.
 * It always reports success, even if it fails, so that notes queued after it still run.
 */
class CorrectionWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    /** Thrown to stop one lecture when the user cancels it, without stopping the rest. */
    private class Skipped : Exception()

    override suspend fun doWork(): Result {
        val ids = inputData.getStringArray(KEY_IDS)?.toList()
            ?: listOfNotNull(inputData.getString(KEY_ID))
        val app = applicationContext

        if (!ModelStore.isReady(app, ModelStore.offlineAi)) {
            ids.forEach {
                CorrectionManager.set(
                    it, JobState(JobKind.Failed, message = "The offline AI isn't installed yet. Download it in Settings.")
                )
            }
            return Result.success()
        }

        try {
            for ((n, id) in ids.withIndex()) {
                if (!CorrectionManager.isWanted(id)) continue
                val lecture = LectureRepository.find(app, id)
                if (lecture == null) {
                    CorrectionManager.set(id, null)
                    continue
                }

                val prefix = if (ids.size > 1) "Lecture ${n + 1} of ${ids.size}: " else ""
                tryForeground(prefix + "Getting started…", 0, 0)
                try {
                    TranscriptCorrector.run(app, lecture) { done, total ->
                        if (!CorrectionManager.isWanted(id)) throw Skipped()
                        CorrectionManager.set(id, JobState(JobKind.Working, done, total, "Checking words"))
                        tryForeground(prefix + "Checking words: line $done of $total", done, total)
                    }
                    CorrectionManager.set(id, null)
                } catch (e: Skipped) {
                    // Cancelled from the screen; its state is already cleared.
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    CorrectionManager.set(
                        id, JobState(JobKind.Failed, message = e.message ?: "Something went wrong.")
                    )
                } finally {
                    CorrectionManager.bump()
                }
            }
        } finally {
            OnDeviceLlm.release()
        }
        return Result.success()
    }

    private suspend fun tryForeground(text: String, done: Int, total: Int) {
        try {
            setForeground(
                ForegroundInfo(
                    NotesNotifier.FIX_ID,
                    NotesNotifier.progress(applicationContext, "Gist is checking words", text, done, total),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
                )
            )
        } catch (e: Exception) {
            // Not always allowed from the background; the job carries on without it.
        }
    }

    companion object {
        const val KEY_ID = "lecture_id"
        const val KEY_IDS = "lecture_ids"
    }
}
