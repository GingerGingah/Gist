package com.gist.gist.ui.record

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

/** Connects the screen to its ViewModel and handles the microphone and notification permissions. */
@Composable
fun RecordRoute(vm: RecordViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current

    fun granted(permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Notifications are optional: recording works without them, the alert is just hidden.
        if (granted(Manifest.permission.RECORD_AUDIO)) vm.start()
    }

    fun requestStart() {
        val missing = buildList {
            if (!granted(Manifest.permission.RECORD_AUDIO)) add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (missing.isEmpty()) vm.start() else permissionLauncher.launch(missing.toTypedArray())
    }

    RecordScreen(
        ui = ui,
        onSubjectChange = { vm.onSubjectChange(it) },
        onStart = { requestStart() },
        onTogglePause = { vm.togglePause() },
        onStop = { vm.stop() },
        onBookmark = { vm.bookmark() },
        onDownloadModel = { vm.downloadModel() },
        onDismissModel = { vm.dismissModelPrompt() },
        onCancelDownload = { vm.cancelDownload() },
        onAllowMobileData = { vm.onAllowMobileData(it) },
    )
}
