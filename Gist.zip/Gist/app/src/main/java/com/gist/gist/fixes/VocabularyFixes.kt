package com.gist.gist.fixes

import android.content.Context
import com.gist.gist.data.FixState
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.data.TranscriptFixes
import com.gist.gist.settings.AppSettings
import com.gist.gist.text.VocabularyFixer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Applies the user's vocabulary to a lecture that was recorded earlier. It is instant and needs
 * no AI. The original words are kept on the side, so "Undo word corrections" puts them back.
 */
object VocabularyFixes {

    /** Returns how many lines were changed. */
    suspend fun apply(context: Context, lecture: Lecture): Int = withContext(Dispatchers.IO) {
        val fixer = VocabularyFixer(AppSettings.state.value.vocabulary)
        if (!fixer.active) return@withContext 0

        val dir = LectureRepository.dir(context)
        val file = TranscriptFixes.file(dir, lecture.id)
        val saved = TranscriptFixes.read(file)
        val fixes = LinkedHashMap<Long, String>(saved?.fixes ?: emptyMap())

        var changed = 0
        for (line in LectureRepository.loadLines(lecture, applyFixes = true)) {
            val (fixed, replaced) = fixer.fix(line.text)
            if (replaced > 0 && fixed != line.text) {
                fixes[line.startMs] = fixed
                changed++
            }
        }
        if (changed > 0) {
            TranscriptFixes.write(file, FixState(saved?.done ?: 0, fixes))
            CorrectionManager.bump()
        }
        changed
    }
}
