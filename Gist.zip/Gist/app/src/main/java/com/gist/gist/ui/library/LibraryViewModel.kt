package com.gist.gist.ui.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.fixes.CorrectionManager
import com.gist.gist.notes.NotesManager
import com.gist.gist.recording.RecordingSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LectureHit(val lecture: Lecture, val snippet: String)

data class LibraryUiState(
    val loading: Boolean = true,
    val query: String = "",
    val subjects: List<String> = emptyList(),
    val subjectFilter: String? = null,
    val all: List<Lecture> = emptyList(),
    val hits: List<LectureHit> = emptyList(),
    /** Ids of the lectures picked for a bulk action. Empty means normal browsing. */
    val selected: Set<String> = emptySet(),
)

/** Everything the list needs to turn on, change and act on a selection. */
class SelectionActions(
    val toggle: (String) -> Unit,
    val start: (String) -> Unit,
    val clear: () -> Unit,
    val selectAll: () -> Unit,
    val deleteSelected: () -> Unit,
    val setSubject: (String) -> Unit,
)

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val lectures = MutableStateFlow<List<Lecture>>(emptyList())
    private val loaded = MutableStateFlow(false)
    private val query = MutableStateFlow("")
    private val subjectFilter = MutableStateFlow<String?>(null)
    private val selection = MutableStateFlow<Set<String>>(emptySet())

    val ui: StateFlow<LibraryUiState> = combine(
        lectures, loaded, query, subjectFilter, selection
    ) { all, isLoaded, q, filter, picked ->
        val needle = q.trim()
        // Only offer subjects that exist, most recent first.
        val subjects = all.map { it.subject.trim() }.filter { it.isNotEmpty() }.distinct()
        val active = filter?.takeIf { it in subjects }
        val scoped = if (active == null) all else all.filter { it.subject.trim() == active }
        val existing = all.map { it.id }.toSet()
        LibraryUiState(
            loading = !isLoaded,
            query = q,
            subjects = subjects,
            subjectFilter = active,
            all = all,
            hits = scoped.mapNotNull { hitFor(it, needle) },
            selected = picked.filter { it in existing }.toSet(),
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    init {
        // Reload when a recording starts or finishes: the lecture being recorded stays hidden
        // until it is complete, then appears.
        viewModelScope.launch {
            RecordingSession.state
                .map { it.activeFile }
                .distinctUntilChanged()
                .collect { reload() }
        }
        // And when notes jobs start or finish, so "Notes ready" shows up.
        viewModelScope.launch {
            NotesManager.jobs
                .map { it.keys }
                .distinctUntilChanged()
                .collect { reload() }
        }
        // And when word corrections are added or undone.
        viewModelScope.launch {
            CorrectionManager.changes.collect { reload() }
        }
    }

    val selectionActions = SelectionActions(
        toggle = ::toggleSelected,
        start = { id -> selection.value = setOf(id) },
        clear = { selection.value = emptySet() },
        selectAll = { selection.value = ui.value.hits.map { it.lecture.id }.toSet() },
        deleteSelected = ::deleteSelected,
        setSubject = ::setSubjectForSelected,
    )

    fun clearSelection() {
        selection.value = emptySet()
    }

    private fun toggleSelected(id: String) {
        selection.update { if (id in it) it - id else it + id }
    }

    private fun deleteSelected() {
        val chosen = ui.value.all.filter { it.id in ui.value.selected }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { chosen.forEach { LectureRepository.delete(it) } }
            selection.value = emptySet()
            reload()
        }
    }

    private fun setSubjectForSelected(subject: String) {
        val chosen = ui.value.all.filter { it.id in ui.value.selected }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                chosen.forEach { LectureRepository.rename(it, subject.trim()) }
            }
            reload()
        }
    }

    fun onQueryChange(value: String) {
        query.value = value
    }

    fun onSubjectFilter(value: String?) {
        subjectFilter.value = value
    }

    fun refresh() {
        viewModelScope.launch { reload() }
    }

    fun rename(lecture: Lecture, subject: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LectureRepository.rename(lecture, subject) }
            reload()
        }
    }

    fun delete(lecture: Lecture) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LectureRepository.delete(lecture) }
            reload()
        }
    }

    private suspend fun reload() {
        lectures.value = LectureRepository.loadAll(
            getApplication(), RecordingSession.state.value.activeFile
        )
        loaded.value = true
    }

    private fun hitFor(lecture: Lecture, needle: String): LectureHit? {
        if (needle.isEmpty()) return LectureHit(lecture, lecture.text.take(160).trim())

        val inText = lecture.text.indexOf(needle, ignoreCase = true)
        val inNotes = lecture.notesText.indexOf(needle, ignoreCase = true)
        val inSubject = lecture.subject.contains(needle, ignoreCase = true)
        if (inText < 0 && inNotes < 0 && !inSubject) return null

        val snippet = when {
            inText >= 0 -> around(lecture.text, inText, needle.length)
            inNotes >= 0 -> "Notes: " + around(lecture.notesText, inNotes, needle.length)
            else -> lecture.text.take(160).trim()
        }
        return LectureHit(lecture, snippet)
    }

    private fun around(text: String, at: Int, length: Int): String {
        val start = (at - 50).coerceAtLeast(0)
        val end = (at + length + 90).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") +
            text.substring(start, end).trim() +
            (if (end < text.length) "…" else "")
    }
}
