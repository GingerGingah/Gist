package com.gist.gist.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gist.gist.transcription.ModelState
import com.gist.gist.transcription.ModelStore
import com.gist.gist.ui.formatBytes

/** A switch that needs extra files first: asks to download them before it can be turned on. */
private class Ask(val pack: ModelStore.Pack, val reason: String, val onConfirm: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(lectureCount: Int, vm: SettingsViewModel = viewModel()) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val test by vm.test.collectAsStateWithLifecycle()
    val storage by vm.storage.collectAsStateWithLifecycle()
    val packStates by ModelStore.states.collectAsStateWithLifecycle()
    var ask by remember { mutableStateOf<Ask?>(null) }

    LaunchedEffect(Unit) { ModelStore.refresh(context) }
    LaunchedEffect(lectureCount) { vm.refreshStorage() }

    fun stateOf(pack: ModelStore.Pack): ModelState = packStates[pack.id] ?: ModelState.Checking

    // Turning a feature on: do it straight away if its files are installed, otherwise ask first.
    fun toggleNeeding(pack: ModelStore.Pack, reason: String, on: Boolean, apply: (Boolean) -> Unit) {
        when {
            !on -> apply(false)
            stateOf(pack) == ModelState.Ready -> apply(true)
            else -> ask = Ask(pack, reason) { apply(true) }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Settings", fontWeight = FontWeight.SemiBold) })
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                SettingsCard("AI notes (your server)") {
                    Text(
                        "Notes can be written by a model on your own server, reached over Tailscale. " +
                            "Only the transcript text is sent, never the audio.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = settings.serverUrl,
                        onValueChange = vm::setServer,
                        singleLine = true,
                        label = { Text("Server address") },
                        placeholder = { Text("e.g. gist-ai or 100.64.0.7") },
                        supportingText = { Text("The usual port (11434) is added if you leave it out") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = settings.model,
                        onValueChange = vm::setModel,
                        singleLine = true,
                        label = { Text("Model") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = vm::testConnection) { Text("Test connection") }
                    Spacer(Modifier.height(8.dp))

                    when (val t = test) {
                        TestState.Idle -> Unit

                        TestState.Testing -> Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(12.dp))
                            Text("Checking…", style = MaterialTheme.typography.bodyMedium)
                        }

                        is TestState.Success -> Column {
                            Text(
                                if (t.modelInstalled) "Connected. \"${settings.model}\" is installed."
                                else "Connected, but \"${settings.model}\" isn't installed. " +
                                    "On the server, run: ollama pull ${settings.model}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (t.modelInstalled) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.error,
                            )
                            if (t.models.isNotEmpty()) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Installed on your server (tap to use):",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(vertical = 8.dp),
                                ) {
                                    items(t.models) { name ->
                                        AssistChip(onClick = { vm.setModel(name) }, label = { Text(name) })
                                    }
                                }
                            }
                        }

                        is TestState.Failure -> Text(
                            t.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    SwitchRow(
                        title = "Write notes automatically",
                        subtitle = "Starts after each lecture and waits for your server if needed",
                        checked = settings.autoNotes,
                        onChange = vm::setAutoNotes,
                    )
                }

                SettingsCard("Offline AI") {
                    Text(
                        "A small AI that runs on this phone with no internet. It is slower and " +
                            "simpler than your server's, but nothing ever leaves the phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    PackRow(
                        pack = ModelStore.offlineAi,
                        state = stateOf(ModelStore.offlineAi),
                        canRemove = true,
                        onDownload = { ModelStore.start(context, false, ModelStore.offlineAi) },
                        onRemove = { ModelStore.cancel(context, ModelStore.offlineAi) },
                    )
                    Spacer(Modifier.height(12.dp))
                    SwitchRow(
                        title = "Full offline mode",
                        subtitle = "Write notes on this phone instead of on your server",
                        checked = settings.offlineNotes,
                        onChange = { on ->
                            toggleNeeding(
                                ModelStore.offlineAi,
                                "Full offline mode writes your notes on this phone, with no server.",
                                on,
                                vm::setOfflineNotes,
                            )
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    SwitchRow(
                        title = "Check words in context",
                        subtitle = "After each lecture, fixes mis-heard words, like \"cash\" for \"cache\"",
                        checked = settings.wordCheck,
                        onChange = { on ->
                            toggleNeeding(
                                ModelStore.offlineAi,
                                "Word checking uses a small AI on this phone to fix mis-heard words.",
                                on,
                                vm::setWordCheck,
                            )
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "It works hard: expect noticeable battery use and about 2 GB of memory while " +
                            "it runs. It waits while you record and only starts when the battery " +
                            "isn't low, so plugging in helps.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SettingsCard("Speakers") {
                    Text(
                        "Tells voices apart while you record, so you can see when someone else " +
                            "speaks, such as a student asking a question. Speaker 1 is whoever " +
                            "talks first.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    PackRow(
                        pack = ModelStore.speaker,
                        state = stateOf(ModelStore.speaker),
                        canRemove = true,
                        onDownload = { ModelStore.start(context, false, ModelStore.speaker) },
                        onRemove = { ModelStore.cancel(context, ModelStore.speaker) },
                    )
                    Spacer(Modifier.height(12.dp))
                    SwitchRow(
                        title = "Tell speakers apart",
                        subtitle = "Applies to lectures you record from now on",
                        checked = settings.speakerDetection,
                        onChange = { on ->
                            toggleNeeding(
                                ModelStore.speaker,
                                "Telling speakers apart needs a small voice model.",
                                on,
                                vm::setSpeakerDetection,
                            )
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Sensitivity", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = settings.speakerSensitivity,
                        onValueChange = vm::setSpeakerSensitivity,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            "Fewer speakers",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "More speakers",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "If one person keeps being split into two, move it left. If different " +
                            "people get merged, move it right.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SettingsCard("Speech model") {
                    PackRow(
                        pack = ModelStore.speech,
                        state = stateOf(ModelStore.speech),
                        canRemove = false,
                        onDownload = { ModelStore.start(context, false, ModelStore.speech) },
                        onRemove = { ModelStore.cancel(context, ModelStore.speech) },
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Needed for live transcription, which then works fully offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SettingsCard("Storage") {
                    Text(
                        "${formatBytes(storage)} used by $lectureCount lecture" +
                            if (lectureCount == 1) "" else "s",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Audio takes roughly 115 MB per hour. To free space, open a lecture, save " +
                            "a copy from its menu, then delete it. Downloaded models are stored " +
                            "separately and can be removed above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SettingsCard("About") {
                    Text(
                        "Audio and transcripts stay on this phone. The only thing that can leave " +
                            "it is transcript text, sent to the server you choose when you ask " +
                            "for notes, and not even that in full offline mode.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    ask?.let { a ->
        AlertDialog(
            onDismissRequest = { ask = null },
            title = { Text("Download prerequisites?") },
            text = {
                Text(
                    "${a.reason}\n\nThis needs a one-time download of ${a.pack.sizeText} " +
                        "(${a.pack.title.lowercase()}, Wi-Fi only). After that it works offline."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    ModelStore.start(context, false, a.pack)
                    a.onConfirm()
                    ask = null
                }) { Text("Download") }
            },
            dismissButton = { TextButton(onClick = { ask = null }) { Text("Not now") } },
        )
    }
}

/** Status of one download pack, with the right button for its state. */
@Composable
private fun PackRow(
    pack: ModelStore.Pack,
    state: ModelState,
    canRemove: Boolean,
    onDownload: () -> Unit,
    onRemove: () -> Unit,
) {
    when (state) {
        ModelState.Ready -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${pack.title}: installed",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            if (canRemove) TextButton(onClick = onRemove) { Text("Remove") }
        }

        is ModelState.Downloading -> Column {
            if (state.totalBytes > 0) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (state.waiting) "${pack.title}: waiting for Wi-Fi…"
                else "${pack.title}: ${formatBytes(state.doneBytes)} of ${formatBytes(state.totalBytes)}",
                style = MaterialTheme.typography.bodyMedium,
            )
            TextButton(onClick = onRemove) { Text("Cancel") }
        }

        is ModelState.Failed -> Column {
            Text(state.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDownload) { Text("Try again") }
        }

        else -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${pack.title}: not installed (${pack.sizeText})",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(onClick = onDownload) { Text("Download") }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}
