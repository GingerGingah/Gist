package com.gist.gist.data

/** "Character [charIndex] starts being spoken [offsetMs] after the line begins." */
data class Mark(val charIndex: Int, val offsetMs: Int)

/**
 * One spoken stretch of a lecture. [marks] holds real timings from the speech model when it
 * provided them; otherwise the timing of each letter is estimated from the line's duration.
 */
class TranscriptLine(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    private val marks: List<Mark>? = null,
    /** Which voice said it (0 = the first voice heard); always 0 if speakers weren't detected. */
    val speaker: Int = 0,
    /** The words as first transcribed, if the offline AI corrected this line. */
    val original: String? = null,
) {
    /** For each character, when it starts being spoken (ms after [startMs]); one extra at the end. */
    val charTimes: IntArray by lazy {
        TimingMath.build(text, (endMs - startMs).coerceAtLeast(1), marks)
    }

    /** A copy with corrected text (real token timings no longer fit, so they are dropped). */
    fun withText(corrected: String) =
        TranscriptLine(startMs, endMs, corrected, null, speaker, original = text)

    /** How many characters have been spoken by [positionMs] on the audio timeline. */
    fun charsSpokenAt(positionMs: Long): Int {
        val rel = positionMs - startMs
        if (rel < 0) return 0
        val times = charTimes
        var lo = 0
        var hi = text.length
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (times[mid] <= rel) lo = mid + 1 else hi = mid
        }
        return lo
    }
}

internal object TimingMath {

    fun build(text: String, durationMs: Long, marks: List<Mark>?): IntArray =
        if (marks != null && marks.size >= 2) fromMarks(text.length, durationMs, marks)
        else estimate(text, durationMs)

    /**
     * Spreads the line's duration over its characters. Letters take time, spaces very little,
     * and punctuation holds a short pause, which is how speech actually flows.
     */
    fun estimate(text: String, durationMs: Long): IntArray {
        val n = text.length
        val times = IntArray(n + 1)
        if (n == 0) return times
        val weights = DoubleArray(n) { weight(text, it) }
        val total = weights.sum()
        var acc = 0.0
        for (i in 0 until n) {
            times[i] = (durationMs * acc / total).toInt()
            acc += weights[i]
        }
        times[n] = durationMs.toInt()
        return times
    }

    private fun weight(text: String, i: Int): Double {
        val c = text[i]
        // The pause after the very last character is not part of the speech.
        if (i == text.length - 1 && !c.isLetterOrDigit()) return 0.3
        return when {
            c.isLetterOrDigit() -> 1.0
            c == ' ' -> 0.4
            c == ',' || c == ';' || c == ':' -> 3.0
            c == '.' || c == '?' || c == '!' -> 5.0
            else -> 0.3
        }
    }

    /** Joins real timing points with straight lines between them. */
    private fun fromMarks(len: Int, durationMs: Long, marks: List<Mark>): IntArray {
        if (len == 0) return IntArray(1)

        val pts = ArrayList<Mark>()
        var lastIndex = -1
        var lastOffset = 0
        for (m in marks.sortedBy { it.charIndex }) {
            val idx = m.charIndex.coerceIn(0, len)
            if (idx <= lastIndex) continue
            val off = maxOf(m.offsetMs, lastOffset)
            pts.add(Mark(idx, off))
            lastIndex = idx
            lastOffset = off
        }
        if (pts.isEmpty() || pts.first().charIndex > 0) pts.add(0, Mark(0, 0))
        if (pts.last().charIndex < len) {
            pts.add(Mark(len, maxOf(durationMs.toInt(), pts.last().offsetMs)))
        }
        if (pts.size < 2) return estimate("x".repeat(len), durationMs)

        val out = IntArray(len + 1)
        var k = 0
        for (i in 0..len) {
            while (k < pts.size - 2 && i >= pts[k + 1].charIndex) k++
            val a = pts[k]
            val b = pts[k + 1]
            val span = (b.charIndex - a.charIndex).coerceAtLeast(1)
            val t = a.offsetMs + (i - a.charIndex).toLong() * (b.offsetMs - a.offsetMs) / span
            out[i] = t.toInt().coerceAtLeast(0)
        }
        return out
    }
}
