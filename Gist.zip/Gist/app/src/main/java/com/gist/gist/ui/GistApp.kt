package com.gist.gist.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gist.gist.recording.RecState
import com.gist.gist.recording.RecordingSession
import com.gist.gist.ui.library.LectureDetailScreen
import com.gist.gist.ui.library.LecturePlayer
import com.gist.gist.ui.library.LibraryScreen
import com.gist.gist.ui.library.LibraryViewModel
import com.gist.gist.ui.record.RecordRoute
import com.gist.gist.ui.settings.SettingsScreen
import kotlinx.coroutines.delay

private enum class Tab(val label: String) {
    Record("Record"),
    Library("Lectures"),
    Settings("Settings"),
}

private fun iconFor(tab: Tab) = when (tab) {
    Tab.Record -> Icons.Rounded.Mic
    Tab.Library -> Icons.Rounded.Description
    Tab.Settings -> Icons.Rounded.Settings
}

/**
 * The app shell.
 *
 * Folded (cover screen): bottom tabs, and a lecture opens full screen.
 * Unfolded (inner screen): a side rail, and the Lectures tab shows the list and the open lecture
 * side by side.
 */
@Composable
fun GistApp() {
    val wide = LocalConfiguration.current.screenWidthDp >= 600

    var tab by rememberSaveable { mutableStateOf(Tab.Record) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var openQuery by rememberSaveable { mutableStateOf("") }

    val library: LibraryViewModel = viewModel()
    val selection = library.selectionActions
    val state by library.ui.collectAsStateWithLifecycle()
    val session by RecordingSession.state.collectAsStateWithLifecycle()
    val opened = openId?.let { id -> state.all.firstOrNull { it.id == id } }

    // One player for the open lecture, kept here so it survives folding and unfolding.
    val player = remember(opened?.id) { opened?.let { LecturePlayer.create(it.audioFile) } }
    DisposableEffect(player) { onDispose { player?.release() } }
    LaunchedEffect(player) {
        if (player != null) {
            while (true) {
                player.refresh()
                // Fast while playing, so the letters can follow the voice.
                delay(if (player.isPlaying) 33L else 250L)
            }
        }
    }

    // Lecture audio must never play into a live recording, or carry on from another tab.
    val recording = session.state != RecState.Idle
    LaunchedEffect(recording, tab) {
        if ((recording || tab != Tab.Library) && player?.isPlaying == true) player.toggle()
    }

    val openSettings = {
        openId = null
        tab = Tab.Settings
    }

    val fullScreenDetail = !wide && tab == Tab.Library && opened != null
    BackHandler(enabled = fullScreenDetail) { openId = null }
    // Declared last so Back leaves selection mode before it does anything else.
    BackHandler(enabled = state.selected.isNotEmpty()) { library.clearSelection() }

    if (fullScreenDetail && opened != null) {
        LectureDetailScreen(
            lecture = opened,
            query = openQuery,
            player = player,
            embedded = false,
            onBack = { openId = null },
            onRename = { library.rename(opened, it) },
            onDelete = {
                library.delete(opened)
                openId = null
            },
            onOpenSettings = openSettings,
        )
    } else {
        Scaffold(
            contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
            bottomBar = {
                if (!wide) {
                    NavigationBar {
                        Tab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(iconFor(t), contentDescription = null) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .consumeWindowInsets(padding),
            ) {
                if (wide) {
                    NavigationRail {
                        Tab.entries.forEach { t ->
                            NavigationRailItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(iconFor(t), contentDescription = null) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .then(
                            // No bottom bar here, so keep content clear of the gesture bar and keyboard.
                            if (wide) Modifier.windowInsetsPadding(
                                WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom)
                            ) else Modifier
                        ),
                ) {
                    when (tab) {
                        Tab.Record -> RecordRoute()

                        Tab.Settings -> SettingsScreen(lectureCount = state.all.size)

                        Tab.Library -> if (wide) {
                            Row(Modifier.fillMaxSize()) {
                                Box(
                                    Modifier
                                        .width(380.dp)
                                        .fillMaxHeight()
                                ) {
                                    LibraryScreen(
                                        state = state,
                                        onQueryChange = { library.onQueryChange(it) },
                                        onSubjectFilter = { library.onSubjectFilter(it) },
                                        onOpen = {
                                            openId = it.id
                                            openQuery = state.query.trim()
                                        },
                                        onVisible = { library.refresh() },
                                        selection = selection,
                                        selectedId = openId,
                                    )
                                }
                                VerticalDivider()
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                ) {
                                    if (opened != null) {
                                        LectureDetailScreen(
                                            lecture = opened,
                                            query = openQuery,
                                            player = player,
                                            embedded = true,
                                            onBack = null,
                                            onRename = { library.rename(opened, it) },
                                            onDelete = {
                                                library.delete(opened)
                                                openId = null
                                            },
                                            onOpenSettings = openSettings,
                                        )
                                    } else {
                                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            Text(
                                                "Select a lecture to read it and play the audio.",
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            LibraryScreen(
                                state = state,
                                onQueryChange = { library.onQueryChange(it) },
                                onSubjectFilter = { library.onSubjectFilter(it) },
                                onOpen = {
                                    openId = it.id
                                    openQuery = state.query.trim()
                                },
                                onVisible = { library.refresh() },
                                        selection = selection,
                            )
                        }
                    }
                }
            }
        }
    }
}
