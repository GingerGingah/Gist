package com.gist.gist.ui.library

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gist.gist.data.Lecture
import com.gist.gist.fixes.CorrectionManager
import com.gist.gist.notes.JobKind
import com.gist.gist.notes.NotesManager
import com.gist.gist.transcription.ModelStore
import com.gist.gist.ui.dayBucket
import com.gist.gist.ui.formatDate
import com.gist.gist.ui.formatDuration
import com.gist.gist.ui.highlight
import kotlinx.coroutines.launch

private sealed interface ListRow {
    data class Header(val text: String) : ListRow
    data class Card(val hit: LectureHit) : ListRow
}

private fun buildRows(hits: List<LectureHit>): List<ListRow> {
    val rows = ArrayList<ListRow>()
    var last = ""
    for (hit in hits) {
        val bucket = dayBucket(hit.lecture.startedAt)
        if (bucket != last) {
            rows.add(ListRow.Header(bucket))
            last = bucket
        }
        rows.add(ListRow.Card(hit))
    }
    return rows
}

/**
 * The list of lectures. Press and hold one to start picking: then tap others to add or remove
 * them, and use the bar at the top to share, delete or work on all the picked lectures at once.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    state: LibraryUiState,
    onQueryChange: (String) -> Unit,
    onSubjectFilter: (String?) -> Unit,
    onOpen: (Lecture) -> Unit,
    onVisible: () -> Unit,
    selection: SelectionActions,
    selectedId: String? = null,
) {
    // Pick up anything new each time the tab is opened.
    LaunchedEffect(Unit) { onVisible() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val jobs by NotesManager.jobs.collectAsStateWithLifecycle()
    val rows = remember(state.hits) { buildRows(state.hits) }

    val selecting = state.selected.isNotEmpty()
    val chosen = state.all.filter { it.id in state.selected }

    var shareMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var askSubject by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf<String?>(null) }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_LONG).show()

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null && chosen.isNotEmpty()) {
            val list = chosen
            scope.launch {
                working = "Saving 1 of ${list.size}…"
                val saved = BulkOps.saveToFolder(context, uri, list) { done, total ->
                    working = "Saving ${done + 1} of $total…"
                }
                working = null
                toast("Saved $saved of ${list.size} lectures")
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        topBar = {
            if (selecting) {
                TopAppBar(
                    title = { Text("${state.selected.size} selected", fontWeight = FontWeight.SemiBold) },
                    navigationIcon = {
                        IconButton(onClick = selection.clear) {
                            Icon(Icons.Rounded.Close, contentDescription = "Stop selecting")
                        }
                    },
                    actions = {
                        IconButton(onClick = selection.selectAll) {
                            Icon(Icons.Rounded.SelectAll, contentDescription = "Select all")
                        }
                        Box {
                            IconButton(onClick = { shareMenu = true }) {
                                Icon(Icons.Rounded.Share, contentDescription = "Share")
                            }
                            DropdownMenu(expanded = shareMenu, onDismissRequest = { shareMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Share transcripts") },
                                    onClick = {
                                        shareMenu = false
                                        scope.launch { BulkOps.shareTranscripts(context, chosen) }
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Share notes") },
                                    onClick = {
                                        shareMenu = false
                                        scope.launch {
                                            if (BulkOps.shareNotes(context, chosen) == 0) {
                                                toast("None of the selected lectures have notes yet")
                                            }
                                        }
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Share audio") },
                                    onClick = {
                                        shareMenu = false
                                        BulkOps.shareAudio(context, chosen)
                                    },
                                )
                            }
                        }
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete")
                        }
                        Box {
                            IconButton(onClick = { moreMenu = true }) {
                                Icon(Icons.Rounded.MoreVert, contentDescription = "More actions")
                            }
                            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Write notes") },
                                    onClick = {
                                        moreMenu = false
                                        val todo = chosen.filter { it.transcriptFile != null && !it.hasNotes }
                                        when {
                                            !NotesManager.canWrite(context) ->
                                                toast("Set up your server or Full offline mode in Settings first")
                                            todo.isEmpty() ->
                                                toast("These lectures already have notes, or have no transcript")
                                            else -> {
                                                NotesManager.enqueueMany(context, todo.map { it.id })
                                                toast("Writing notes for ${todo.size} lecture" + if (todo.size == 1) "" else "s")
                                                selection.clear()
                                            }
                                        }
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Check words with AI") },
                                    onClick = {
                                        moreMenu = false
                                        val todo = chosen.filter { it.transcriptFile != null }
                                        when {
                                            !ModelStore.isReady(context, ModelStore.offlineAi) ->
                                                toast("Download the Offline AI in Settings first")
                                            todo.isEmpty() -> toast("None of these lectures have a transcript")
                                            else -> {
                                                CorrectionManager.enqueueMany(context, todo.map { it.id })
                                                toast("Checking words in ${todo.size} lecture" + if (todo.size == 1) "" else "s")
                                                selection.clear()
                                            }
                                        }
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Set subject…") },
                                    onClick = {
                                        moreMenu = false
                                        askSubject = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Save to folder…") },
                                    onClick = {
                                        moreMenu = false
                                        folderPicker.launch(null)
                                    },
                                )
                            }
                        }
                    },
                )
            } else {
                CenterAlignedTopAppBar(
                    title = { Text("Lectures", fontWeight = FontWeight.SemiBold) }
                )
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
            ) {
                OutlinedTextField(
                    value = state.query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    placeholder = { Text("Search lectures, transcripts and notes") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (state.query.isNotEmpty()) {
                            IconButton(onClick = { onQueryChange("") }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                if (state.subjects.size >= 2) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 8.dp),
                    ) {
                        item {
                            FilterChip(
                                selected = state.subjectFilter == null,
                                onClick = { onSubjectFilter(null) },
                                label = { Text("All") },
                            )
                        }
                        items(state.subjects) { subject ->
                            FilterChip(
                                selected = state.subjectFilter == subject,
                                onClick = { onSubjectFilter(subject) },
                                label = { Text(subject) },
                            )
                        }
                    }
                } else {
                    Spacer(Modifier.height(12.dp))
                }

                when {
                    state.loading -> Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 48.dp),
                        contentAlignment = Alignment.Center,
                    ) { CircularProgressIndicator() }

                    rows.isEmpty() -> EmptyState(state)

                    else -> LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 16.dp),
                    ) {
                        items(
                            rows,
                            key = {
                                when (it) {
                                    is ListRow.Header -> "header:" + it.text
                                    is ListRow.Card -> it.hit.lecture.id
                                }
                            },
                        ) { row ->
                            when (row) {
                                is ListRow.Header -> Text(
                                    text = row.text,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                                )

                                is ListRow.Card -> {
                                    val id = row.hit.lecture.id
                                    LectureCard(
                                        hit = row.hit,
                                        query = state.query.trim(),
                                        open = id == selectedId,
                                        checked = id in state.selected,
                                        notesRunning = jobs[id]?.kind.let {
                                            it == JobKind.Working || it == JobKind.Queued ||
                                                it == JobKind.WaitingForServer
                                        },
                                        onClick = {
                                            if (selecting) selection.toggle(id) else onOpen(row.hit.lecture)
                                        },
                                        onLongClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            if (selecting) selection.toggle(id) else selection.start(id)
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        val n = state.selected.size
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (n == 1) "Delete this lecture?" else "Delete $n lectures?") },
            text = {
                Text("The audio, transcripts and notes will be removed from this phone. This can't be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    selection.deleteSelected()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }

    if (askSubject) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { askSubject = false },
            title = { Text("Set subject for ${state.selected.size} lectures") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text("Subject or course") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    selection.setSubject(text)
                    askSubject = false
                    selection.clear()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { askSubject = false }) { Text("Cancel") } },
        )
    }

    working?.let { message ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Saving lectures") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(16.dp))
                    Text(message)
                }
            },
            confirmButton = {},
        )
    }
}

@Composable
private fun EmptyState(state: LibraryUiState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp, start = 16.dp, end = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Rounded.Description,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.outline,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = if (state.all.isEmpty()) "No lectures yet.\nRecord one and it will appear here."
            else "Nothing matches your search.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LectureCard(
    hit: LectureHit,
    query: String,
    open: Boolean,
    checked: Boolean,
    notesRunning: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val lecture = hit.lecture
    val scheme = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = when {
            checked -> scheme.secondaryContainer
            open -> scheme.primaryContainer
            else -> scheme.surfaceContainerLow
        },
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .combinedClickable(onClick = onClick, onLongClick = onLongClick)
                .padding(16.dp),
        ) {
            Avatar(lecture.title, lecture.subject, checked)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = highlight(lecture.title, query, scheme.onTertiaryContainer, scheme.tertiaryContainer),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${formatDate(lecture.startedAt)}  ·  ${formatDuration(lecture.durationMs)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = scheme.onSurfaceVariant,
                )
                if (hit.snippet.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = highlight(hit.snippet, query, scheme.onTertiaryContainer, scheme.tertiaryContainer),
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurface,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                val hasPills = lecture.hasNotes || notesRunning || lecture.bookmarks.isNotEmpty() ||
                    lecture.transcriptFile == null || lecture.speakers > 1
                if (hasPills) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (notesRunning) Pill("Writing notes…", scheme.secondaryContainer, scheme.onSecondaryContainer)
                        else if (lecture.hasNotes) Pill("Notes ready", scheme.tertiaryContainer, scheme.onTertiaryContainer)
                        if (lecture.bookmarks.isNotEmpty()) {
                            val n = lecture.bookmarks.size
                            Pill("$n bookmark" + if (n == 1) "" else "s", scheme.surfaceVariant, scheme.onSurfaceVariant)
                        }
                        if (lecture.speakers > 1) {
                            Pill("${lecture.speakers} speakers", scheme.surfaceVariant, scheme.onSurfaceVariant)
                        }
                        if (lecture.transcriptFile == null) {
                            Pill("Audio only", scheme.surfaceVariant, scheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

/** A coloured initial, or a tick when the lecture is picked. */
@Composable
private fun Avatar(title: String, subject: String, checked: Boolean) {
    val scheme = MaterialTheme.colorScheme
    if (checked) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(scheme.primary, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = "Selected",
                tint = scheme.onPrimary,
                modifier = Modifier.size(24.dp),
            )
        }
        return
    }
    val palette = listOf(
        scheme.primaryContainer to scheme.onPrimaryContainer,
        scheme.secondaryContainer to scheme.onSecondaryContainer,
        scheme.tertiaryContainer to scheme.onTertiaryContainer,
    )
    val (background, foreground) = palette[(subject.hashCode() and 0x7fffffff) % palette.size]
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(background, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = title.first().uppercase(),
            color = foreground,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.titleMedium,
        )
    }
}

@Composable
private fun Pill(text: String, background: Color, foreground: Color) {
    Surface(color = background, shape = RoundedCornerShape(50)) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = foreground,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}
