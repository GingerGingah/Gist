package com.gist.gist.notes

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.WorkManager
import com.gist.gist.fixes.CorrectionManager
import com.gist.gist.settings.AppSettings
import com.gist.gist.transcription.ModelStore

/** Decides what happens automatically once a lecture has been recorded. */
object PostProcessing {

    fun afterRecording(context: Context, id: String) {
        val app = context.applicationContext
        val settings = AppSettings.state.value
        val aiReady = ModelStore.isReady(app, ModelStore.offlineAi)

        val check = settings.wordCheck && aiReady
        val notes = settings.autoNotes && (settings.configured || (settings.offlineNotes && aiReady))

        when {
            // Check the words first, so the notes are written from the corrected text.
            check && notes -> {
                CorrectionManager.set(id, com.gist.gist.notes.JobState(JobKind.Queued))
                NotesManager.set(id, JobState(JobKind.Queued))
                WorkManager.getInstance(app)
                    .beginUniqueWork("post_$id", ExistingWorkPolicy.KEEP, CorrectionManager.request(listOf(id)))
                    .then(NotesManager.request(app, listOf(id)))
                    .enqueue()
            }
            check -> CorrectionManager.enqueue(app, id)
            notes -> NotesManager.enqueue(app, id)
        }
    }
}
