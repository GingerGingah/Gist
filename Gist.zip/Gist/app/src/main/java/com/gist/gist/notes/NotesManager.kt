package com.gist.gist.notes

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.gist.gist.data.LectureRepository
import com.gist.gist.settings.AppSettings
import com.gist.gist.transcription.ModelStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

enum class JobKind { Queued, WaitingForServer, Working, Failed }

data class JobState(
    val kind: JobKind,
    val done: Int = 0,
    val total: Int = 0,
    val message: String? = null,
)

/**
 * Starts and cancels notes jobs, and shares their progress with the screen. A job using the
 * server waits for a connection and retries if it can't be reached; a job in full offline mode
 * needs no connection at all. Either way it resumes where it stopped. Several lectures can be
 * queued at once; they are written one after another so a small server isn't overloaded.
 */
object NotesManager {

    private val _jobs = MutableStateFlow<Map<String, JobState>>(emptyMap())

    /** Lectures with notes queued, in progress, waiting for the server, or failed. */
    val jobs: StateFlow<Map<String, JobState>> = _jobs.asStateFlow()

    /** Lectures the user cancelled, so a batch that is already running skips them. */
    private val cancelled: MutableSet<String> = ConcurrentHashMap.newKeySet()

    internal fun set(id: String, state: JobState?) {
        _jobs.update { map -> if (state == null) map - id else map + (id to state) }
    }

    internal fun isWanted(id: String) = id !in cancelled

    /** True if notes will be written on the phone instead of on the server. */
    fun runsOffline(context: Context): Boolean =
        AppSettings.state.value.offlineNotes && ModelStore.isReady(context, ModelStore.offlineAi)

    /** True if there is somewhere to write notes: the server, or full offline mode. */
    fun canWrite(context: Context): Boolean =
        AppSettings.state.value.configured || runsOffline(context)

    internal fun request(context: Context, ids: List<String>): OneTimeWorkRequest {
        val constraints = Constraints.Builder().apply {
            if (runsOffline(context)) setRequiresBatteryNotLow(true)
            else setRequiredNetworkType(NetworkType.CONNECTED)
        }.build()
        return OneTimeWorkRequestBuilder<NotesWorker>()
            .setInputData(workDataOf(NotesWorker.KEY_IDS to ids.toTypedArray()))
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 60, TimeUnit.SECONDS)
            .build()
    }

    fun enqueue(context: Context, id: String, regenerate: Boolean = false) {
        val app = context.applicationContext
        if (regenerate) NotesStore.deleteAll(LectureRepository.dir(app), id)
        cancelled.remove(id)
        set(id, JobState(JobKind.Queued))
        WorkManager.getInstance(app).enqueueUniqueWork(
            "notes_$id",
            if (regenerate) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
            request(app, listOf(id)),
        )
    }

    /** Writes notes for several lectures, one after another. */
    fun enqueueMany(context: Context, ids: List<String>) {
        if (ids.isEmpty()) return
        val app = context.applicationContext
        ids.forEach {
            cancelled.remove(it)
            set(it, JobState(JobKind.Queued))
        }
        WorkManager.getInstance(app).enqueueUniqueWork(
            "notes_batch",
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            request(app, ids),
        )
    }

    fun cancel(context: Context, id: String) {
        cancelled.add(id)
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork("notes_$id")
        set(id, null)
    }
}
