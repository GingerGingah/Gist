package com.gist.gist.ui.record

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.gist.gist.recording.RecState
import com.gist.gist.transcription.ModelState
import com.gist.gist.ui.formatClock
import com.gist.gist.ui.theme.GistTheme
import kotlin.math.PI
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordScreen(
    ui: RecordUiState,
    onSubjectChange: (String) -> Unit,
    onStart: () -> Unit,
    onTogglePause: () -> Unit,
    onStop: () -> Unit,
    onBookmark: () -> Unit,
    onDownloadModel: () -> Unit,
    onDismissModel: () -> Unit,
    onCancelDownload: () -> Unit,
    onAllowMobileData: (Boolean) -> Unit,
) {
    // Unfolded (inner screen): controls on the left, the live transcript on the right.
    val wide = LocalConfiguration.current.screenWidthDp >= 600

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Gist", fontWeight = FontWeight.SemiBold) }
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            if (wide) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .imePadding()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .width(300.dp)
                            .fillMaxHeight()
                    ) {
                        SubjectField(ui, onSubjectChange)
                        Spacer(Modifier.height(12.dp))
                        Notice(ui)
                        if (showModelCard(ui)) {
                            ModelCard(ui, onDownloadModel, onDismissModel, onCancelDownload, onAllowMobileData)
                        }
                        Spacer(Modifier.weight(1f))
                        Meter(ui)
                        Spacer(Modifier.height(16.dp))
                        Controls(ui.state, ui.finalizing, ui.bookmarks, onStart, onTogglePause, onBookmark, onStop)
                    }
                    TranscriptCard(
                        ui = ui,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .widthIn(max = 640.dp)
                        .fillMaxSize()
                        .imePadding()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 16.dp),
                ) {
                    SubjectField(ui, onSubjectChange)
                    Spacer(Modifier.height(12.dp))
                    Notice(ui)
                    if (showModelCard(ui)) {
                        ModelCard(ui, onDownloadModel, onDismissModel, onCancelDownload, onAllowMobileData)
                    }
                    TranscriptCard(
                        ui = ui,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    )
                    Spacer(Modifier.height(20.dp))
                    Meter(ui)
                    Spacer(Modifier.height(16.dp))
                    Controls(ui.state, ui.finalizing, ui.bookmarks, onStart, onTogglePause, onBookmark, onStop)
                }
            }
        }
    }
}

@Composable
private fun SubjectField(ui: RecordUiState, onSubjectChange: (String) -> Unit) {
    OutlinedTextField(
        value = ui.subject,
        onValueChange = onSubjectChange,
        enabled = ui.state == RecState.Idle && !ui.finalizing,
        singleLine = true,
        label = { Text("Subject or course") },
        supportingText = { Text("Saved with the lecture and used to guide your notes") },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    )
}

/** Waveform and timer. */
@Composable
private fun Meter(ui: RecordUiState) {
    Column {
        Waveform(
            active = ui.state == RecState.Recording && !ui.finalizing,
            level = ui.level,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = formatClock(ui.elapsedMs),
            style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Light,
                fontFeatureSettings = "tnum",
            ),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

private fun showModelCard(ui: RecordUiState): Boolean = when (ui.model) {
    is ModelState.Downloading -> true
    ModelState.Missing, is ModelState.Failed ->
        ui.state == RecState.Idle && !ui.finalizing && !ui.promptDismissed
    else -> false
}

/** Shown only when something needs the user's attention. */
@Composable
private fun Notice(ui: RecordUiState) {
    val message = when {
        ui.error != null -> ui.error
        ui.micSilenced -> "Another app is using the microphone, so audio is silent right now."
        else -> null
    } ?: return
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        )
    }
}

/** The one-time "Download prerequisites?" step. */
@Composable
private fun ModelCard(
    ui: RecordUiState,
    onDownload: () -> Unit,
    onDismiss: () -> Unit,
    onCancel: () -> Unit,
    onAllowMobileData: (Boolean) -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
    ) {
        Column(Modifier.padding(20.dp)) {
            when (val model = ui.model) {
                is ModelState.Downloading -> {
                    Text(
                        "Downloading the speech model",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(12.dp))
                    if (model.totalBytes > 0) {
                        LinearProgressIndicator(
                            progress = { model.progress },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = when {
                            model.waiting -> "Waiting for Wi-Fi…"
                            model.totalBytes > 0 ->
                                "${megabytes(model.doneBytes)} of ${megabytes(model.totalBytes)} MB"
                            else -> "Starting…"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    TextButton(onClick = onCancel) { Text("Cancel") }
                }

                is ModelState.Failed -> {
                    Text(
                        "The download didn't finish",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(model.message, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    Row {
                        Button(onClick = onDownload) { Text("Try again") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = onDismiss) { Text("Not now") }
                    }
                }

                else -> {
                    Text(
                        "Download prerequisites?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Gist needs a one-time download (about 400 MB) to transcribe on your " +
                            "phone. After that, nothing leaves the device.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = ui.allowMobileData, onCheckedChange = onAllowMobileData)
                        Spacer(Modifier.width(12.dp))
                        Text("Allow mobile data", style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row {
                        Button(onClick = onDownload) { Text("Download") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = onDismiss) { Text("Not now") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TranscriptCard(ui: RecordUiState, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "Live transcript",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                StatusPill(ui.state, ui.finalizing)
            }

            Spacer(Modifier.height(12.dp))

            val hasText = ui.transcript.isNotBlank()
            val modelReady = ui.model is ModelState.Ready
            val body = when {
                hasText -> ui.transcript
                ui.finalizing -> "Finishing the transcript…"
                ui.state == RecState.Recording && ui.transcribing -> "Listening…"
                ui.state == RecState.Recording && modelReady -> "Loading the speech model…"
                ui.state == RecState.Recording ->
                    "Recording audio only. Install the speech model to get a live transcript."
                ui.state == RecState.Paused -> "Paused. Resume to keep transcribing."
                else -> "Start recording and the transcript will appear here as the lecture goes."
            }

            val scroll = rememberScrollState()
            // Follow new text, unless the reader has scrolled up to look back.
            var previousMax by remember { mutableIntStateOf(0) }
            LaunchedEffect(scroll.maxValue) {
                val wasAtBottom = scroll.value >= previousMax - 150
                previousMax = scroll.maxValue
                if (wasAtBottom) scroll.animateScrollTo(scroll.maxValue)
            }

            Text(
                text = body,
                style = MaterialTheme.typography.bodyLarge,
                color = if (hasText) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scroll),
            )
        }
    }
}

@Composable
private fun StatusPill(state: RecState, finalizing: Boolean) {
    val label: String
    val dot = when {
        finalizing -> {
            label = "Finishing"
            MaterialTheme.colorScheme.primary
        }
        state == RecState.Idle -> {
            label = "Ready"
            MaterialTheme.colorScheme.outline
        }
        state == RecState.Recording -> {
            label = "Recording"
            MaterialTheme.colorScheme.error
        }
        else -> {
            label = "Paused"
            MaterialTheme.colorScheme.tertiary
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .background(dot, CircleShape)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * Animated bars that rise and fall with the real microphone [level], so a quiet room
 * stays flat and a voice makes them move.
 */
@Composable
private fun Waveform(active: Boolean, level: Float, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMillis = 1800, easing = LinearEasing)),
        label = "phase",
    )
    val amplitude by animateFloatAsState(if (active) 1f else 0f, label = "amplitude")
    val color = MaterialTheme.colorScheme.primary

    Canvas(modifier) {
        val bars = 32
        val gap = 6.dp.toPx()
        val barWidth = (size.width - gap * (bars - 1)) / bars
        val minHeight = 4.dp.toPx()
        val drive = level.coerceIn(0f, 1f)
        for (i in 0 until bars) {
            val wave = (sin(phase + i * 0.45f) + 1f) / 2f
            val h = minHeight + (size.height - minHeight) * wave * amplitude * drive
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (barWidth + gap), (size.height - h) / 2f),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2f),
            )
        }
    }
}

@Composable
private fun Controls(
    state: RecState,
    finalizing: Boolean,
    bookmarks: Int,
    onStart: () -> Unit,
    onTogglePause: () -> Unit,
    onBookmark: () -> Unit,
    onStop: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(124.dp),
        contentAlignment = Alignment.Center,
    ) {
        when {
            finalizing -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(12.dp))
                Text("Finishing transcript…", style = MaterialTheme.typography.bodyLarge)
            }

            state == RecState.Idle -> StartButton {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onStart()
            }

            else -> Row(
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BadgedBox(badge = { if (bookmarks > 0) Badge { Text("$bookmarks") } }) {
                    FilledTonalIconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onBookmark()
                        },
                        modifier = Modifier.size(56.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.BookmarkAdd,
                            contentDescription = "Bookmark this moment",
                            modifier = Modifier.size(26.dp),
                        )
                    }
                }
                FilledTonalIconButton(
                    onClick = onTogglePause,
                    modifier = Modifier.size(64.dp),
                ) {
                    Icon(
                        imageVector = if (state == RecState.Recording) Icons.Rounded.Pause
                        else Icons.Rounded.PlayArrow,
                        contentDescription = if (state == RecState.Recording) "Pause" else "Resume",
                        modifier = Modifier.size(30.dp),
                    )
                }
                FilledIconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onStop()
                    },
                    modifier = Modifier.size(80.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Stop,
                        contentDescription = "Stop recording",
                        modifier = Modifier.size(36.dp),
                    )
                }
            }
        }
    }
}

/** A large round button with a slowly breathing halo, inviting a tap. */
@Composable
private fun StartButton(onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "halo")
    val halo by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "halo",
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(80.dp)
                    .graphicsLayer {
                        scaleX = halo
                        scaleY = halo
                        alpha = 0.22f
                    }
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            )
            FilledIconButton(
                onClick = onClick,
                modifier = Modifier.size(80.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Mic,
                    contentDescription = "Start recording",
                    modifier = Modifier.size(38.dp),
                )
            }
        }
        Text(
            "Tap to record",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun megabytes(bytes: Long): String = "%.0f".format(bytes / 1_048_576.0)

@Preview(showBackground = true, heightDp = 780)
@Composable
private fun RecordScreenPreview() {
    GistTheme {
        RecordScreen(
            ui = RecordUiState(
                state = RecState.Recording,
                elapsedMs = 754_000,
                level = 0.6f,
                transcribing = true,
                transcript = "Today we're looking at how the Fourier transform moves a signal " +
                    "from the time domain into the frequency domain.\n\nFirst, a quick recap.",
                model = ModelState.Ready,
            ),
            onSubjectChange = {},
            onStart = {},
            onTogglePause = {},
            onStop = {},
            onBookmark = {},
            onDownloadModel = {},
            onDismissModel = {},
            onCancelDownload = {},
            onAllowMobileData = {},
        )
    }
}
