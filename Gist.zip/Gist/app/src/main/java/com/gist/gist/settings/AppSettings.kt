package com.gist.gist.settings

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

const val DEFAULT_MODEL = "qwen2.5:3b"

data class Settings(
    val serverUrl: String = "",
    val model: String = DEFAULT_MODEL,
    val autoNotes: Boolean = false,
    /** Tell voices apart while recording (needs the speaker model). */
    val speakerDetection: Boolean = false,
    /** 0 = fewer speakers, 1 = more speakers. */
    val speakerSensitivity: Float = 0.5f,
    /** Write notes on this phone instead of on the server (needs the offline AI). */
    val offlineNotes: Boolean = false,
    /** Check words in context after each lecture (needs the offline AI). */
    val wordCheck: Boolean = false,
) {
    val configured: Boolean get() = serverUrl.isNotBlank()
}

/** The few things the user can change. Saved on the phone. */
object AppSettings {
    private val _state = MutableStateFlow(Settings())
    val state: StateFlow<Settings> = _state.asStateFlow()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("gist_settings", Context.MODE_PRIVATE)
        prefs = p
        _state.value = Settings(
            serverUrl = p.getString("server_url", "") ?: "",
            model = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL,
            autoNotes = p.getBoolean("auto_notes", false),
            speakerDetection = p.getBoolean("speaker_detection", false),
            speakerSensitivity = p.getFloat("speaker_sensitivity", 0.5f),
            offlineNotes = p.getBoolean("offline_notes", false),
            wordCheck = p.getBoolean("word_check", false),
        )
    }

    fun update(block: (Settings) -> Settings) {
        val next = block(_state.value)
        _state.value = next
        prefs?.edit()
            ?.putString("server_url", next.serverUrl)
            ?.putString("model", next.model)
            ?.putBoolean("auto_notes", next.autoNotes)
            ?.putBoolean("speaker_detection", next.speakerDetection)
            ?.putFloat("speaker_sensitivity", next.speakerSensitivity)
            ?.putBoolean("offline_notes", next.offlineNotes)
            ?.putBoolean("word_check", next.wordCheck)
            ?.apply()
    }

    /** "gist-ai" becomes "http://gist-ai:11434"; the usual port is added if it's left out. */
    fun baseUrl(raw: String): String {
        var s = raw.trim().trimEnd('/')
        if (s.isEmpty()) return s
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        val scheme = s.substringBefore("://")
        val hostAndPort = s.substringAfter("://").substringBefore('/')
        val withPort = if (hostAndPort.contains(':') || scheme == "https") hostAndPort
        else "$hostAndPort:11434"
        return "$scheme://$withPort"
    }
}
