package com.gist.gist.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 05:12 or 1:05:12 */
fun formatClock(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/** 45 s, 52 min, 1 h 05 min */
fun formatDuration(ms: Long): String {
    if (ms < 60_000) return "${ms / 1000} s"
    val minutes = ms / 60_000
    val h = minutes / 60
    val m = minutes % 60
    return if (h > 0) "%d h %02d min".format(h, m) else "$m min"
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

/** Marks every occurrence of [query] in [text]. */
fun highlight(text: String, query: String, color: Color, background: Color): AnnotatedString {
    if (query.isBlank()) return AnnotatedString(text)
    return buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            val hit = text.indexOf(query, i, ignoreCase = true)
            if (hit < 0) {
                append(text.substring(i))
                break
            }
            append(text.substring(i, hit))
            withStyle(
                SpanStyle(background = background, color = color, fontWeight = FontWeight.SemiBold)
            ) {
                append(text.substring(hit, hit + query.length))
            }
            i = hit + query.length
        }
    }
}

/** "Today", "Yesterday", "Previous 7 days", then "October 2026" and so on. */
fun dayBucket(ms: Long): String {
    fun dayStart(t: Long): Long {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = t
        c.set(java.util.Calendar.HOUR_OF_DAY, 0)
        c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0)
        c.set(java.util.Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
    // Adding half a day before dividing keeps this right across clock changes.
    val days = (dayStart(System.currentTimeMillis()) - dayStart(ms) + 43_200_000L) / 86_400_000L
    return when {
        days <= 0 -> "Today"
        days == 1L -> "Yesterday"
        days < 8 -> "Previous 7 days"
        else -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(ms))
    }
}

/** 340 MB, 1.2 GB */
fun formatBytes(bytes: Long): String {
    val mb = bytes / 1_048_576.0
    return if (mb >= 1024) "%.1f GB".format(mb / 1024) else "%.0f MB".format(mb)
}
