package com.gist.gist.data

import java.io.File

data class Lecture(
    /** Matches the file names, e.g. "lecture_20261014_153000". */
    val id: String,
    val subject: String,
    val startedAt: Long,
    val durationMs: Long,
    val audioFile: File,
    /** Human-readable transcript (.txt). */
    val transcriptFile: File?,
    /** Precise timings for each spoken line (.jsonl), written by newer recordings. */
    val timingFile: File?,
    val metaFile: File,
    /** The whole transcript as plain text, used for search and previews. */
    val text: String,
    /** Moments the user flagged while recording, in ms. */
    val bookmarks: List<Long> = emptyList(),
    val hasNotes: Boolean = false,
    /** The notes as plain text, used for search. */
    val notesText: String = "",
    /** How many different voices were heard (1 if speakers weren't detected). */
    val speakers: Int = 1,
    /** Lines the offline AI corrected. */
    val fixCount: Int = 0,
) {
    val title: String get() = subject.ifBlank { "Untitled lecture" }
}
