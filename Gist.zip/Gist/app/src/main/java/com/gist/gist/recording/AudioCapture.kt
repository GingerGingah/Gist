package com.gist.gist.recording

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioRecordingConfiguration
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Reads the microphone at 16 kHz mono (what Whisper-style models expect) and writes it to disk
 * as it goes. Pausing releases the microphone completely, so the privacy indicator goes off too.
 */
class AudioCapture(
    private val context: Context,
    private val outFile: File,
    private val onFailure: (String) -> Unit,
) {
    @Volatile
    private var paused = false
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        job = scope.launch(Dispatchers.IO) { capture() }
    }

    fun setPaused(value: Boolean) {
        paused = value
    }

    suspend fun stopAndJoin() {
        job?.cancelAndJoin()
    }

    fun cancel() {
        job?.cancel()
    }

    @SuppressLint("MissingPermission")
    private suspend fun capture() {
        val rate = RecordingSession.SAMPLE_RATE
        val minBuffer = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            onFailure("This phone can't record audio at 16 kHz.")
            return
        }

        val record = try {
            AudioRecord.Builder()
                // Tuned for speech recognition: avoids heavy automatic gain and music processing.
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuffer, FRAME_SAMPLES * 2 * 16))
                .build()
        } catch (e: Exception) {
            onFailure("Couldn't open the microphone.")
            return
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            onFailure("Couldn't open the microphone.")
            return
        }

        // Tells us when another app (a phone call, for example) has silenced our microphone.
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val callback = object : AudioManager.AudioRecordingCallback() {
            override fun onRecordingConfigChanged(configs: List<AudioRecordingConfiguration>) {
                val mine = configs.firstOrNull { it.clientAudioSessionId == record.audioSessionId }
                RecordingSession.update { it.copy(micSilenced = mine?.isClientSilenced == true) }
            }
        }
        audioManager.registerAudioRecordingCallback(callback, Handler(Looper.getMainLooper()))

        var wav: WavWriter? = null
        var recording = false
        try {
            wav = WavWriter(outFile, rate)
            val frame = ShortArray(FRAME_SAMPLES)
            var totalSamples = 0L
            var smoothed = 0f
            var frameCount = 0
            var lastPatch = SystemClock.elapsedRealtime()

            while (currentCoroutineContext().isActive) {
                if (paused) {
                    if (recording) {
                        record.stop()
                        recording = false
                        RecordingSession.update {
                            it.copy(state = RecState.Paused, level = 0f, micSilenced = false)
                        }
                    }
                    delay(80)
                    continue
                }
                if (!recording) {
                    RecordingSession.preRoll.clear()
                    record.startRecording()
                    recording = true
                    RecordingSession.update { it.copy(state = RecState.Recording) }
                }

                val n = record.read(frame, 0, frame.size)
                if (n < 0) {
                    onFailure("The microphone stopped working (error $n).")
                    break
                }
                if (n == 0) continue

                wav.write(frame, n)
                RecordingSession.publishFrame(frame, n)
                totalSamples += n
                smoothed = smooth(smoothed, levelOf(frame, n))

                // Update the screen about 10 times a second instead of on every frame.
                frameCount++
                if (frameCount % 3 == 0) {
                    val elapsed = totalSamples * 1000 / rate
                    RecordingSession.update { it.copy(elapsedMs = elapsed, level = smoothed) }
                }

                val now = SystemClock.elapsedRealtime()
                if (now - lastPatch >= 2_000) {
                    wav.patchHeader()
                    lastPatch = now
                }
            }
            RecordingSession.update { it.copy(elapsedMs = totalSamples * 1000 / rate) }
        } catch (e: IOException) {
            onFailure("Couldn't save the audio. Is the phone's storage full?")
        } finally {
            try {
                if (recording) record.stop()
            } catch (e: IllegalStateException) {
                // Already stopped.
            }
            record.release()
            audioManager.unregisterAudioRecordingCallback(callback)
            try {
                wav?.close()
            } catch (e: IOException) {
                // Nothing more we can do.
            }
        }
    }

    /** Microphone level on a 0..1 scale (roughly -60 dB to -20 dB, which suits speech). */
    private fun levelOf(buf: ShortArray, n: Int): Float {
        var sum = 0.0
        for (i in 0 until n) {
            val v = buf[i] / 32768.0
            sum += v * v
        }
        val rms = sqrt(sum / n).coerceAtLeast(1e-6)
        val db = 20 * log10(rms)
        return ((db + 60) / 40).toFloat().coerceIn(0f, 1f)
    }

    /** Fast rise, slow fall, so the meter feels alive without flickering. */
    private fun smooth(previous: Float, current: Float): Float {
        val k = if (current > previous) 0.6f else 0.15f
        return previous + (current - previous) * k
    }

    companion object {
        /** 512 samples = 32 ms, the frame size common voice-activity detectors expect. */
        const val FRAME_SAMPLES = 512
    }
}
