package com.gist.gist.ai

import android.content.Context
import com.gist.gist.transcription.ModelStore
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * A small language model (Qwen 2.5 1.5B) running entirely on the phone through Google's
 * MediaPipe. Used for full offline notes and for checking words in context.
 * This is the only file that talks to MediaPipe.
 */
object OnDeviceLlm {

    /** Room for the question and the answer together. Matches the downloaded model file. */
    private const val MAX_TOKENS = 4096

    private val lock = Mutex()
    private var engine: LlmInference? = null

    /** One question, one answer. Questions are handled one at a time. */
    suspend fun complete(context: Context, system: String, user: String): String =
        withContext(Dispatchers.Default) {
            lock.withLock {
                val llm = engine ?: create(context).also { engine = it }
                // Qwen models expect their conversation in this layout.
                val prompt = "<|im_start|>system\n$system<|im_end|>\n" +
                    "<|im_start|>user\n$user<|im_end|>\n" +
                    "<|im_start|>assistant\n"
                llm.generateResponse(prompt)
                    .substringBefore("<|im_end|>")
                    .trim()
            }
        }

    /** Frees the memory the model uses. It reloads (about 10 seconds) when next needed. */
    suspend fun release() {
        lock.withLock {
            try {
                engine?.close()
            } catch (e: Exception) {
                // Nothing more to do.
            }
            engine = null
        }
    }

    private fun create(context: Context): LlmInference {
        val model = File(ModelStore.dir(context, ModelStore.offlineAi), ModelStore.OFFLINE_FILE)
        if (!model.exists()) throw IllegalStateException("The offline AI isn't installed. Download it in Settings.")
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(model.absolutePath)
            .setMaxTokens(MAX_TOKENS)
            .build()
        return LlmInference.createFromOptions(context.applicationContext, options)
    }
}
