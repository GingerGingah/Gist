package com.gist.gist.ui.record

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gist.gist.recording.RecState
import com.gist.gist.recording.RecordingService
import com.gist.gist.recording.RecordingSession
import com.gist.gist.transcription.ModelState
import com.gist.gist.transcription.ModelStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update

data class RecordUiState(
    val state: RecState = RecState.Idle,
    val elapsedMs: Long = 0L,
    val subject: String = "",
    /** 0..1 microphone level. */
    val level: Float = 0f,
    val transcript: String = "",
    val transcribing: Boolean = false,
    val finalizing: Boolean = false,
    val micSilenced: Boolean = false,
    val error: String? = null,
    val bookmarks: Int = 0,
    val model: ModelState = ModelState.Checking,
    val promptDismissed: Boolean = false,
    val allowMobileData: Boolean = false,
)

class RecordViewModel(app: Application) : AndroidViewModel(app) {

    private data class Local(
        val subject: String = "",
        val dismissed: Boolean = false,
        val mobileData: Boolean = false,
    )

    private val local = MutableStateFlow(Local())

    val ui: StateFlow<RecordUiState> = combine(
        local, RecordingSession.state, ModelStore.state
    ) { l, session, model ->
        RecordUiState(
            state = session.state,
            elapsedMs = session.elapsedMs,
            subject = l.subject,
            level = session.level,
            transcript = session.transcript,
            transcribing = session.transcribing,
            finalizing = session.finalizing,
            micSilenced = session.micSilenced,
            error = session.error,
            bookmarks = session.bookmarks.size,
            model = model,
            promptDismissed = l.dismissed,
            allowMobileData = l.mobileData,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecordUiState())

    init {
        ModelStore.refresh(app)
    }

    fun onSubjectChange(value: String) {
        local.update { it.copy(subject = value) }
    }

    fun onAllowMobileData(value: Boolean) {
        local.update { it.copy(mobileData = value) }
    }

    fun dismissModelPrompt() {
        local.update { it.copy(dismissed = true) }
    }

    fun downloadModel() {
        local.update { it.copy(dismissed = false) }
        ModelStore.start(getApplication(), local.value.mobileData)
    }

    fun cancelDownload() {
        ModelStore.cancel(getApplication())
    }

    fun start() {
        RecordingService.start(getApplication(), local.value.subject.trim())
    }

    fun togglePause() {
        when (RecordingSession.state.value.state) {
            RecState.Recording ->
                RecordingService.send(getApplication(), RecordingService.ACTION_PAUSE)
            RecState.Paused ->
                RecordingService.send(getApplication(), RecordingService.ACTION_RESUME)
            RecState.Idle -> Unit
        }
    }

    fun bookmark() {
        RecordingService.send(getApplication(), RecordingService.ACTION_BOOKMARK)
    }

    fun stop() {
        RecordingService.send(getApplication(), RecordingService.ACTION_STOP)
    }
}
