package com.gist.gist.fixes

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.gist.gist.data.LectureRepository
import com.gist.gist.data.TranscriptFixes
import com.gist.gist.notes.JobKind
import com.gist.gist.notes.JobState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Starts and cancels word-checking jobs and shares their progress with the screen. */
object CorrectionManager {

    private val _jobs = MutableStateFlow<Map<String, JobState>>(emptyMap())

    /** Lectures being checked (or whose check failed), by lecture id. */
    val jobs: StateFlow<Map<String, JobState>> = _jobs.asStateFlow()

    private val _changes = MutableStateFlow(0)

    /** Goes up whenever corrections are added or removed, so lists can reload. */
    val changes: StateFlow<Int> = _changes.asStateFlow()

    private val cancelled: MutableSet<String> = ConcurrentHashMap.newKeySet()

    internal fun set(id: String, state: JobState?) {
        _jobs.update { map -> if (state == null) map - id else map + (id to state) }
    }

    internal fun bump() {
        _changes.update { it + 1 }
    }

    internal fun isWanted(id: String) = id !in cancelled

    internal fun request(ids: List<String>): OneTimeWorkRequest =
        OneTimeWorkRequestBuilder<CorrectionWorker>()
            .setInputData(workDataOf(CorrectionWorker.KEY_IDS to ids.toTypedArray()))
            // It works on the phone, so it needs no connection; but it is heavy on the battery.
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 60, TimeUnit.SECONDS)
            .build()

    fun enqueue(context: Context, id: String) {
        cancelled.remove(id)
        set(id, JobState(JobKind.Queued))
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork("fix_$id", ExistingWorkPolicy.KEEP, request(listOf(id)))
    }

    /** Checks several lectures, one after another. */
    fun enqueueMany(context: Context, ids: List<String>) {
        if (ids.isEmpty()) return
        ids.forEach {
            cancelled.remove(it)
            set(it, JobState(JobKind.Queued))
        }
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork("fix_batch", ExistingWorkPolicy.APPEND_OR_REPLACE, request(ids))
    }

    fun cancel(context: Context, id: String) {
        cancelled.add(id)
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork("fix_$id")
        set(id, null)
    }

    /** Puts the transcript back exactly as it was first transcribed. */
    fun undo(context: Context, id: String) {
        TranscriptFixes.file(LectureRepository.dir(context), id).delete()
        bump()
    }
}
