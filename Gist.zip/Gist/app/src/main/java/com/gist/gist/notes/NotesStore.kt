package com.gist.gist.notes

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

data class NoteSection(val startMs: Long, val endMs: Long, val markdown: String)

data class LectureNotes(
    val model: String,
    val generatedAt: Long,
    val overview: String,
    val keyTerms: String,
    val questions: String,
    val sections: List<NoteSection>,
)

/** Notes live next to the lecture: lecture_<stamp>.notes.json (and a .notes.part.json while working). */
object NotesStore {

    fun file(dir: File, id: String) = File(dir, "$id.notes.json")
    private fun partial(dir: File, id: String) = File(dir, "$id.notes.part.json")

    fun load(dir: File, id: String): LectureNotes? = read(file(dir, id))

    fun read(file: File): LectureNotes? {
        if (!file.exists()) return null
        return try {
            val j = JSONObject(file.readText())
            LectureNotes(
                model = j.optString("model"),
                generatedAt = j.optLong("generatedAt"),
                overview = j.optString("overview"),
                keyTerms = j.optString("keyTerms"),
                questions = j.optString("questions"),
                sections = sectionsFrom(j.optJSONArray("sections")),
            )
        } catch (e: Exception) {
            null
        }
    }

    fun save(dir: File, id: String, notes: LectureNotes) {
        val json = JSONObject()
            .put("model", notes.model)
            .put("generatedAt", notes.generatedAt)
            .put("overview", notes.overview)
            .put("keyTerms", notes.keyTerms)
            .put("questions", notes.questions)
            .put("sections", sectionsTo(notes.sections))
        file(dir, id).writeText(json.toString())
    }

    /** Parts finished so far, so an interrupted job carries on instead of starting over. */
    fun loadPartial(dir: File, id: String): List<NoteSection> {
        val f = partial(dir, id)
        if (!f.exists()) return emptyList()
        return try {
            sectionsFrom(JSONArray(f.readText()))
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePartial(dir: File, id: String, sections: List<NoteSection>) {
        try {
            partial(dir, id).writeText(sectionsTo(sections).toString())
        } catch (e: IOException) {
            // Only costs a restart of the job if it is interrupted.
        }
    }

    fun clearPartial(dir: File, id: String) {
        partial(dir, id).delete()
    }

    fun deleteAll(dir: File, id: String) {
        file(dir, id).delete()
        partial(dir, id).delete()
    }

    /** Plain text of the whole notes, for search. */
    fun plainText(notes: LectureNotes): String =
        (listOf(notes.overview, notes.keyTerms) + notes.sections.map { it.markdown } + notes.questions)
            .joinToString(" ")
            .replace("**", "")
            .replace(Regex("[#`>]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun sectionsFrom(arr: JSONArray?): List<NoteSection> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            NoteSection(o.getLong("s"), o.getLong("e"), o.getString("md"))
        }
    }

    private fun sectionsTo(sections: List<NoteSection>): JSONArray {
        val arr = JSONArray()
        sections.forEach {
            arr.put(JSONObject().put("s", it.startMs).put("e", it.endMs).put("md", it.markdown))
        }
        return arr
    }
}
