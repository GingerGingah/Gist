package com.gist.gist.ui.library

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LinearProgressIndicator
import com.gist.gist.fixes.CorrectionManager
import com.gist.gist.fixes.VocabularyFixes
import com.gist.gist.notes.JobState
import com.gist.gist.transcription.ModelState
import com.gist.gist.transcription.ModelStore
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gist.gist.data.Lecture
import com.gist.gist.data.LectureRepository
import com.gist.gist.data.TranscriptLine
import com.gist.gist.notes.JobKind
import com.gist.gist.notes.LectureNotes
import com.gist.gist.notes.NotesManager
import com.gist.gist.notes.NotesStore
import com.gist.gist.settings.AppSettings
import com.gist.gist.ui.formatClock
import com.gist.gist.ui.formatDate
import com.gist.gist.ui.formatDuration
import com.gist.gist.ui.highlight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * One lecture: audio controls on top, then two tabs: the transcript (the line being spoken is
 * highlighted and its words light up) and the AI-written notes.
 *
 * [player] is owned by the app shell, so playback carries on if the Fold is opened or closed.
 * When [embedded] (the right-hand pane on the unfolded screen) there is no back button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LectureDetailScreen(
    lecture: Lecture,
    query: String,
    player: LecturePlayer?,
    embedded: Boolean,
    onBack: (() -> Unit)?,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val lines by produceState(initialValue = emptyList<TranscriptLine>(), lecture.id, lecture.fixCount, lecture.speakers) {
        value = LectureRepository.loadLines(lecture)
    }

    val jobs by NotesManager.jobs.collectAsStateWithLifecycle()
    val job = jobs[lecture.id]
    val settings by AppSettings.state.collectAsStateWithLifecycle()
    val packStates by ModelStore.states.collectAsStateWithLifecycle()
    val offlineReady = packStates[ModelStore.offlineAi.id] == ModelState.Ready
    // Notes can be written by the server, or on the phone in full offline mode.
    val canWriteNotes = settings.configured || (settings.offlineNotes && offlineReady)
    val fixJobs by CorrectionManager.jobs.collectAsStateWithLifecycle()
    val fixJob = fixJobs[lecture.id]
    var showOriginal by remember(lecture.id) { mutableStateOf(false) }
    val notes by produceState<LectureNotes?>(null, lecture.id, job?.kind, lecture.hasNotes) {
        value = withContext(Dispatchers.IO) {
            NotesStore.load(LectureRepository.dir(context), lecture.id)
        }
    }
    val notesBusy = job != null && job.kind != JobKind.Failed

    var tab by remember(lecture.id) { mutableIntStateOf(0) }

    // Index of the line being spoken. Only changes when playback moves to another line, so the
    // list isn't redrawn on every tick.
    val currentIndex by remember(lines, player) {
        derivedStateOf {
            val p = player?.positionMs ?: 0
            if (p <= 0) -1 else lines.indexOfLast { it.startMs <= p }
        }
    }
    val listState = rememberLazyListState()

    // Opened from a search: jump to the first matching line.
    LaunchedEffect(lines) {
        if (query.isNotBlank()) {
            val first = lines.indexOfFirst { it.text.contains(query, ignoreCase = true) }
            if (first >= 0) listState.scrollToItem(first)
        }
    }
    // While playing, keep the current line in view.
    LaunchedEffect(currentIndex, tab) {
        if (tab == 0 && player?.isPlaying == true && currentIndex >= 0) {
            listState.animateScrollToItem(currentIndex)
        }
    }

    val playFrom: (Long) -> Unit = { ms ->
        player?.seekTo(ms.toInt())
        if (player != null && !player.isPlaying) player.toggle()
    }

    var menuOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val saveTranscript = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    Export.writeText(context, uri, Export.transcriptText(lecture, lines))
                }
                toast(context, if (ok) "Transcript saved" else "Couldn't save the file")
            }
        }
    }
    val saveAudio = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/x-wav")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { Export.writeAudio(context, lecture, uri) }
                toast(context, if (ok) "Audio saved" else "Couldn't save the file")
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        contentWindowInsets = if (embedded) WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)
        else ScaffoldDefaults.contentWindowInsets,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        lecture.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "More options")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(if (notes != null) "Write notes again" else "Write notes") },
                                enabled = !notesBusy,
                                onClick = {
                                    menuOpen = false
                                    if (!canWriteNotes) {
                                        onOpenSettings()
                                    } else {
                                        tab = 1
                                        NotesManager.enqueue(context, lecture.id, regenerate = notes != null)
                                    }
                                },
                            )
                            if (notes != null) {
                                DropdownMenuItem(
                                    text = { Text("Share notes") },
                                    onClick = {
                                        menuOpen = false
                                        notes?.let { Export.shareNotes(context, lecture, it) }
                                    },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Check words with AI") },
                                enabled = fixJob == null || fixJob.kind == JobKind.Failed,
                                onClick = {
                                    menuOpen = false
                                    if (!offlineReady) onOpenSettings()
                                    else CorrectionManager.enqueue(context, lecture.id)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Fix terms from my vocabulary") },
                                onClick = {
                                    menuOpen = false
                                    if (settings.vocabulary.isBlank()) {
                                        toast(context, "Add your terms in Settings first")
                                        onOpenSettings()
                                    } else {
                                        scope.launch {
                                            val n = VocabularyFixes.apply(context, lecture)
                                            toast(
                                                context,
                                                if (n == 0) "No words needed fixing"
                                                else "Fixed $n line" + if (n == 1) "" else "s"
                                            )
                                        }
                                    }
                                },
                            )
                            if (lecture.fixCount > 0) {
                                DropdownMenuItem(
                                    text = { Text("Undo word corrections") },
                                    onClick = {
                                        menuOpen = false
                                        CorrectionManager.undo(context, lecture.id)
                                    },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Share transcript") },
                                onClick = {
                                    menuOpen = false
                                    Export.shareText(context, lecture, lines)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Share audio") },
                                onClick = {
                                    menuOpen = false
                                    Export.shareAudio(context, lecture)
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Save transcript to…") },
                                onClick = {
                                    menuOpen = false
                                    saveTranscript.launch("${Export.baseName(lecture)}.txt")
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Save audio to…") },
                                onClick = {
                                    menuOpen = false
                                    saveAudio.launch("${Export.baseName(lecture)}.wav")
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Rename") },
                                onClick = {
                                    menuOpen = false
                                    renaming = true
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Delete") },
                                onClick = {
                                    menuOpen = false
                                    deleting = true
                                },
                            )
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
            ) {
                Text(
                    text = "${formatDate(lecture.startedAt)}  ·  ${formatDuration(lecture.durationMs)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))

                PlaybackCard(player)

                if (lecture.bookmarks.isNotEmpty()) {
                    BookmarkChips(lecture.bookmarks, playFrom)
                } else {
                    Spacer(Modifier.height(8.dp))
                }

                TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Transcript") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Notes") })
                }

                if (tab == 0) {
                    val emptyMessage = if (lecture.transcriptFile == null) {
                        "No transcript for this recording. It was saved as audio only."
                    } else {
                        "The transcript is empty."
                    }
                    if (fixJob != null) {
                        CorrectionBanner(fixJob) { CorrectionManager.cancel(context, lecture.id) }
                    } else if (lecture.fixCount > 0) {
                        FixesBar(
                            count = lecture.fixCount,
                            showOriginal = showOriginal,
                            onToggle = { showOriginal = !showOriginal },
                            onUndo = { CorrectionManager.undo(context, lecture.id) },
                        )
                    }
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    ) {
                        if (lines.isEmpty()) {
                            item {
                                Text(
                                    text = emptyMessage,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(8.dp),
                                )
                            }
                        }
                        itemsIndexed(lines) { index, line ->
                            TranscriptRow(
                                line = line,
                                current = index == currentIndex,
                                bookmarked = lecture.bookmarks.any { it in line.startMs..(line.endMs + 1_500) },
                                speaker = if (lecture.speakers > 1) line.speaker else null,
                                showOriginal = showOriginal,
                                player = player,
                                query = query,
                                onClick = { playFrom(line.startMs) },
                            )
                        }
                    }
                } else {
                    NotesPane(
                        notes = notes,
                        job = job,
                        serverConfigured = canWriteNotes,
                        onWrite = { NotesManager.enqueue(context, lecture.id) },
                        onRegenerate = {
                            NotesManager.enqueue(context, lecture.id, regenerate = true)
                        },
                        onCancel = { NotesManager.cancel(context, lecture.id) },
                        onSeek = playFrom,
                        onOpenSettings = onOpenSettings,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    )
                }
            }
        }
    }

    if (renaming) {
        var text by remember { mutableStateOf(lecture.subject) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Rename lecture") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text("Subject or course") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRename(text.trim())
                    renaming = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }

    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Delete this lecture?") },
            text = { Text("The audio, transcript and notes will be removed from this phone. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    onDelete()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun BookmarkChips(bookmarks: List<Long>, onSeek: (Long) -> Unit) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        items(bookmarks) { ms ->
            AssistChip(
                onClick = { onSeek(ms) },
                label = { Text(formatClock(ms)) },
                leadingIcon = {
                    Icon(Icons.Rounded.Bookmark, contentDescription = null, modifier = Modifier.size(18.dp))
                },
            )
        }
    }
}

/**
 * One transcript line. If it is the line being spoken, its words light up as they are said:
 * spoken letters are bright, upcoming ones dim, and the letter being said has a marker.
 */
@Composable
private fun TranscriptRow(
    line: TranscriptLine,
    current: Boolean,
    bookmarked: Boolean,
    speaker: Int?,
    showOriginal: Boolean,
    player: LecturePlayer?,
    query: String,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (current) scheme.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Column(Modifier.width(56.dp)) {
            Text(
                text = formatClock(line.startMs),
                style = MaterialTheme.typography.labelLarge,
                color = scheme.primary,
            )
            if (speaker != null) {
                Text(
                    text = "S${speaker + 1}",
                    style = MaterialTheme.typography.labelSmall,
                    color = speakerColor(speaker, scheme),
                    fontWeight = FontWeight.SemiBold,
                )
            }
            if (bookmarked) {
                Icon(
                    Icons.Rounded.Bookmark,
                    contentDescription = "Bookmarked",
                    tint = scheme.tertiary,
                    modifier = Modifier.size(16.dp),
                )
            }
        }

        if (current && player != null && !(showOriginal && line.original != null)) {
            // Reading the position here means only this row redraws as playback moves.
            val position = player.positionMs.toLong()
            val finished = position - line.startMs >= line.endMs - line.startMs
            val shown = if (finished) {
                AnnotatedString(line.text)
            } else {
                wordByWord(
                    text = line.text,
                    spoken = line.charsSpokenAt(position),
                    done = scheme.onPrimaryContainer,
                    upcoming = scheme.onPrimaryContainer.copy(alpha = 0.45f),
                    markerText = scheme.onPrimary,
                    markerBackground = scheme.primary,
                )
            }
            Text(
                text = shown,
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onPrimaryContainer,
            )
        } else {
            val display = if (showOriginal) line.original ?: line.text else line.text
            Text(
                text = if (query.isBlank() && line.original != null && !showOriginal) {
                    underlineChanges(line.text, line.original)
                } else {
                    highlight(display, query, scheme.onTertiaryContainer, scheme.tertiaryContainer)
                },
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onSurface,
            )
        }
    }
}

/** Lights up one word at a time: words already said are bright, the one being said is marked. */
private fun wordByWord(
    text: String,
    spoken: Int,
    done: Color,
    upcoming: Color,
    markerText: Color,
    markerBackground: Color,
): AnnotatedString = buildAnnotatedString {
    if (spoken <= 0 || text.isEmpty()) {
        withStyle(SpanStyle(color = upcoming)) { append(text) }
        return@buildAnnotatedString
    }
    // The word that contains the latest letter said (skipping back over a space).
    var at = (spoken - 1).coerceAtMost(text.length - 1)
    while (at > 0 && text[at] == ' ') at--
    var start = at
    while (start > 0 && text[start - 1] != ' ') start--
    var end = at
    while (end < text.length && text[end] != ' ') end++

    if (start > 0) withStyle(SpanStyle(color = done)) { append(text.substring(0, start)) }
    withStyle(
        SpanStyle(color = markerText, background = markerBackground, fontWeight = FontWeight.SemiBold)
    ) { append(text.substring(start, end)) }
    if (end < text.length) withStyle(SpanStyle(color = upcoming)) { append(text.substring(end)) }
}

/** The corrected line, with the words the AI changed underlined. */
private fun underlineChanges(corrected: String, original: String): AnnotatedString {
    val words = corrected.split(' ')
    val before = original.split(' ')
    return buildAnnotatedString {
        words.forEachIndexed { i, word ->
            if (i > 0) append(' ')
            if (before.size == words.size && before[i] != word) {
                withStyle(
                    SpanStyle(textDecoration = TextDecoration.Underline, fontWeight = FontWeight.SemiBold)
                ) { append(word) }
            } else {
                append(word)
            }
        }
    }
}

private fun speakerColor(index: Int, scheme: ColorScheme): Color = listOf(
    scheme.primary, scheme.tertiary, scheme.secondary, scheme.error, scheme.outline, scheme.inversePrimary,
)[index % 6]

@Composable
private fun FixesBar(count: Int, showOriginal: Boolean, onToggle: () -> Unit, onUndo: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "$count line${if (count == 1) "" else "s"} corrected by AI",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onToggle) { Text(if (showOriginal) "Show corrected" else "Show original") }
        TextButton(onClick = onUndo) { Text("Undo") }
    }
}

@Composable
private fun CorrectionBanner(job: JobState, onCancel: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            if (job.kind == JobKind.Failed) {
                Text(
                    job.message ?: "Checking the words didn't work.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            } else {
                Text(
                    if (job.total > 0) "Checking words: line ${job.done} of ${job.total}" else "Checking words…",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                if (job.total > 0) {
                    LinearProgressIndicator(
                        progress = { job.done.toFloat() / job.total },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
            TextButton(onClick = onCancel) {
                Text(if (job.kind == JobKind.Failed) "Dismiss" else "Cancel")
            }
        }
    }
}

private val speeds = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

private fun speedLabel(speed: Float): String =
    (if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()) + "×"

@Composable
private fun PlaybackCard(player: LecturePlayer?) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        if (player == null) {
            Text(
                text = "Couldn't open this recording's audio.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(20.dp),
            )
            return@Surface
        }

        var dragValue by remember { mutableStateOf<Float?>(null) }
        val duration = player.durationMs.coerceAtLeast(1)

        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Slider(
                value = dragValue ?: (player.positionMs.toFloat() / duration),
                onValueChange = { dragValue = it },
                onValueChangeFinished = {
                    dragValue?.let { player.seekTo((it * duration).toInt()) }
                    dragValue = null
                },
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                val shown = dragValue?.let { (it * duration).toLong() } ?: player.positionMs.toLong()
                Text(
                    formatClock(shown),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    formatClock(duration.toLong()),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(
                    onClick = {
                        val next = speeds.indexOfFirst { it >= player.speed - 0.01f } + 1
                        player.changeSpeed(speeds[next % speeds.size])
                    },
                    modifier = Modifier.width(72.dp),
                ) { Text(speedLabel(player.speed)) }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { player.skip(-10_000) }) {
                        Icon(Icons.Rounded.Replay10, contentDescription = "Back 10 seconds")
                    }
                    FilledIconButton(onClick = { player.toggle() }, modifier = Modifier.size(56.dp)) {
                        Icon(
                            imageVector = if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (player.isPlaying) "Pause" else "Play",
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    IconButton(onClick = { player.skip(10_000) }) {
                        Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10 seconds")
                    }
                }

                Spacer(Modifier.width(72.dp))
            }
        }
    }
}

private fun toast(context: android.content.Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}
