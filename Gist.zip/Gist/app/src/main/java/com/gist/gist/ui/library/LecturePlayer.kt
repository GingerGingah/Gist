package com.gist.gist.ui.library

import android.media.MediaPlayer
import android.media.PlaybackParams
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Small wrapper around MediaPlayer that exposes position, speed and play state to Compose. */
class LecturePlayer private constructor(private val mp: MediaPlayer) {

    var positionMs by mutableIntStateOf(0)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var speed by mutableFloatStateOf(1f)
        private set

    val durationMs: Int = mp.duration

    @Volatile
    private var released = false

    init {
        mp.setOnCompletionListener { isPlaying = false }
    }

    fun toggle() {
        if (released) return
        if (mp.isPlaying) {
            mp.pause()
        } else {
            if (mp.currentPosition >= durationMs - 200) mp.seekTo(0)
            mp.start()
        }
        refresh()
    }

    fun seekTo(ms: Int) {
        if (released) return
        val target = ms.coerceIn(0, durationMs)
        mp.seekTo(target)
        positionMs = target
    }

    fun skip(deltaMs: Int) = seekTo(positionMs + deltaMs)

    /** Changing the speed on Android's player also starts it, so pause again if it was paused. */
    fun changeSpeed(value: Float) {
        if (released) return
        try {
            val wasPlaying = mp.isPlaying
            mp.playbackParams = PlaybackParams().setSpeed(value)
            if (!wasPlaying) mp.pause()
            speed = value
        } catch (e: Exception) {
            // Some devices refuse unusual speeds; keep the old one.
        }
    }

    fun refresh() {
        if (released) return
        try {
            isPlaying = mp.isPlaying
            positionMs = mp.currentPosition
        } catch (e: IllegalStateException) {
            // Released while we were reading it.
        }
    }

    fun release() {
        if (released) return
        released = true
        try {
            mp.release()
        } catch (e: Exception) {
            // Nothing more to do.
        }
    }

    companion object {
        /** Returns null if the audio can't be opened. */
        fun create(file: File): LecturePlayer? = try {
            val mp = MediaPlayer()
            mp.setDataSource(file.absolutePath)
            mp.prepare()
            LecturePlayer(mp)
        } catch (e: Exception) {
            null
        }
    }
}
