package com.gist.gist.recording

/**
 * Keeps the most recent audio in memory. The transcription step uses it as a "pre-roll" so the
 * first words after a pause are never clipped.
 */
class PcmRingBuffer(private val capacity: Int) {
    private val data = ShortArray(capacity)
    private var writePos = 0
    private var filled = 0
    private val lock = Any()

    fun write(src: ShortArray, count: Int) {
        synchronized(lock) {
            for (i in 0 until count) {
                data[writePos] = src[i]
                writePos = (writePos + 1) % capacity
            }
            filled = minOf(capacity, filled + count)
        }
    }

    /** Copy of the latest [maxSamples] samples, oldest first. */
    fun snapshot(maxSamples: Int = capacity): ShortArray {
        synchronized(lock) {
            val n = minOf(maxSamples, filled)
            val out = ShortArray(n)
            var idx = (writePos - n + capacity) % capacity
            for (i in 0 until n) {
                out[i] = data[idx]
                idx = (idx + 1) % capacity
            }
            return out
        }
    }

    fun clear() {
        synchronized(lock) {
            writePos = 0
            filled = 0
        }
    }
}
