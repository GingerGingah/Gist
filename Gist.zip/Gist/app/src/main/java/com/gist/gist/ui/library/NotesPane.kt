package com.gist.gist.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.gist.gist.notes.JobKind
import com.gist.gist.notes.JobState
import com.gist.gist.notes.LectureNotes
import com.gist.gist.notes.NoteSection
import com.gist.gist.ui.MarkdownText
import com.gist.gist.ui.formatClock
import com.gist.gist.ui.formatDate

/** The Notes tab of a lecture: progress while writing, or the finished notes. */
@Composable
fun NotesPane(
    notes: LectureNotes?,
    job: JobState?,
    serverConfigured: Boolean,
    onWrite: () -> Unit,
    onRegenerate: () -> Unit,
    onCancel: () -> Unit,
    onSeek: (Long) -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        when {
            job != null -> JobCard(job, onCancel, onWrite)
            notes != null -> NotesContent(notes, onSeek, onRegenerate)
            else -> EmptyNotes(serverConfigured, onWrite, onOpenSettings)
        }
    }
}

@Composable
private fun EmptyNotes(serverConfigured: Boolean, onWrite: () -> Unit, onOpenSettings: () -> Unit) {
    Card2 {
        Icon(
            Icons.Rounded.AutoAwesome,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(32.dp),
        )
        Spacer(Modifier.height(12.dp))
        Text("No notes yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            if (serverConfigured) {
                "Gist sends the transcript (not the audio) to your own server, which writes an " +
                    "overview, notes by time, key terms and review questions. It runs in the " +
                    "background, so you can leave the app."
            } else {
                "Notes are written by an AI model on your own server. Add your server's address " +
                    "in Settings first."
            },
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(16.dp))
        if (serverConfigured) {
            Button(onClick = onWrite) { Text("Write notes") }
        } else {
            Button(onClick = onOpenSettings) { Text("Set up your server") }
        }
    }
}

@Composable
private fun JobCard(job: JobState, onCancel: () -> Unit, onRetry: () -> Unit) {
    Card2 {
        val title = when (job.kind) {
            JobKind.Queued -> "Getting ready"
            JobKind.WaitingForServer -> "Waiting for your server"
            JobKind.Working -> "Writing notes"
            JobKind.Failed -> "Couldn't write the notes"
        }
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))

        when (job.kind) {
            JobKind.Working -> {
                if (job.total > 0) {
                    LinearProgressIndicator(
                        progress = { job.done.toFloat() / job.total },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(8.dp))
                Text(job.message ?: "Working…", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "This can take a while on a small server. You can leave the app; it keeps going.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            JobKind.WaitingForServer -> Text(
                (job.message ?: "Your server didn't answer.") +
                    " Make sure Tailscale is connected on this phone. Gist will keep trying.",
                style = MaterialTheme.typography.bodyMedium,
            )

            JobKind.Queued -> Text(
                "The notes will start as soon as there is a connection.",
                style = MaterialTheme.typography.bodyMedium,
            )

            JobKind.Failed -> Text(
                job.message ?: "Something went wrong.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Spacer(Modifier.height(12.dp))
        Row {
            if (job.kind == JobKind.Failed) {
                Button(onClick = onRetry) { Text("Try again") }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = onCancel) { Text("Dismiss") }
            } else {
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun NotesContent(notes: LectureNotes, onSeek: (Long) -> Unit, onRegenerate: () -> Unit) {
    if (notes.overview.isNotBlank()) SectionCard("Overview", notes.overview)
    if (notes.keyTerms.isNotBlank()) SectionCard("Key terms", notes.keyTerms)

    if (notes.sections.isNotEmpty()) {
        Text(
            "Notes by time",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 4.dp, top = 4.dp),
        )
        notes.sections.forEach { TimedSection(it, onSeek) }
    }

    if (notes.questions.isNotBlank()) SectionCard("Review questions", notes.questions)

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            "Written by ${notes.model}\n${formatDate(notes.generatedAt)}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onRegenerate) { Text("Write again") }
    }
}

@Composable
private fun SectionCard(title: String, markdown: String) {
    Card2 {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        MarkdownText(markdown)
    }
}

/** A part of the lecture's notes. Tap the time to hear that moment. */
@Composable
private fun TimedSection(section: NoteSection, onSeek: (Long) -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier
                .clickable { onSeek(section.startMs) }
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    "${formatClock(section.startMs)} – ${formatClock(section.endMs)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(Modifier.height(8.dp))
            MarkdownText(section.markdown)
        }
    }
}

@Composable
private fun Card2(content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp)) { content() }
    }
}
