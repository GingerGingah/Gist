package com.gist.gist.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.gist.gist.text.cleanMarkdown

/** Shows the small part of Markdown the notes use: headings, bullets, numbers and **bold**. */
@Composable
fun MarkdownText(markdown: String, modifier: Modifier = Modifier) {
    val numbered = Regex("^(\\d+)[.)]\\s+(.*)$")
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        cleanMarkdown(markdown).lines().forEach { raw ->
            val line = raw.trimEnd()
            val trimmed = line.trimStart()
            val indent = (line.length - trimmed.length) / 2 * 12
            when {
                trimmed.isBlank() -> Unit

                trimmed.startsWith("#") -> Text(
                    text = inlineMarkdown(trimmed.trimStart('#').trim()),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )

                trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ") ->
                    Row(Modifier.padding(start = indent.dp)) {
                        Text("•", Modifier.width(18.dp), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            inlineMarkdown(trimmed.substring(2).trim()),
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }

                numbered.matches(trimmed) -> {
                    val m = numbered.matchEntire(trimmed)!!
                    Row(Modifier.padding(start = indent.dp)) {
                        Text("${m.groupValues[1]}.", Modifier.width(24.dp), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            inlineMarkdown(m.groupValues[2]),
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }

                else -> Text(inlineMarkdown(trimmed), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

private fun inlineMarkdown(text: String): AnnotatedString = buildAnnotatedString {
    text.replace("`", "").split("**").forEachIndexed { i, part ->
        if (i % 2 == 1) {
            withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(part) }
        } else {
            append(part)
        }
    }
}
