package com.gist.gist.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Word corrections made by the offline AI, saved beside the lecture so the original transcript
 * is never touched: lecture_<stamp>.fixes.json. [done] is how many lines have been checked.
 */
class FixState(val done: Int, val fixes: Map<Long, String>)

object TranscriptFixes {

    fun file(dir: File, id: String) = File(dir, "$id.fixes.json")

    fun read(file: File): FixState? {
        if (!file.exists()) return null
        return try {
            val j = JSONObject(file.readText())
            val arr = j.optJSONArray("fixes") ?: JSONArray()
            val map = LinkedHashMap<Long, String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                map[o.getLong("s")] = o.getString("t")
            }
            FixState(j.optInt("done", 0), map)
        } catch (e: Exception) {
            null
        }
    }

    fun write(file: File, state: FixState) {
        val arr = JSONArray()
        state.fixes.forEach { (start, text) -> arr.put(JSONObject().put("s", start).put("t", text)) }
        try {
            file.writeText(JSONObject().put("done", state.done).put("fixes", arr).toString())
        } catch (e: IOException) {
            // The next batch will try again.
        }
    }
}
