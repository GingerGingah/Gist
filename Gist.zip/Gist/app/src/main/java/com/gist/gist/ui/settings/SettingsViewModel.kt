package com.gist.gist.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gist.gist.ai.OllamaClient
import com.gist.gist.data.LectureRepository
import com.gist.gist.settings.AppSettings
import com.gist.gist.settings.Settings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface TestState {
    data object Idle : TestState
    data object Testing : TestState
    data class Success(val models: List<String>, val modelInstalled: Boolean) : TestState
    data class Failure(val message: String) : TestState
}

class SettingsViewModel(app: Application) : AndroidViewModel(app) {

    val settings: StateFlow<Settings> = AppSettings.state

    private val _test = MutableStateFlow<TestState>(TestState.Idle)
    val test: StateFlow<TestState> = _test.asStateFlow()

    private val _storage = MutableStateFlow(0L)
    val storage: StateFlow<Long> = _storage.asStateFlow()

    fun setServer(value: String) {
        AppSettings.update { it.copy(serverUrl = value) }
        _test.value = TestState.Idle
    }

    fun setModel(value: String) {
        AppSettings.update { it.copy(model = value.trim()) }
        _test.value = TestState.Idle
    }

    fun setAutoNotes(value: Boolean) {
        AppSettings.update { it.copy(autoNotes = value) }
    }

    fun setSpeakerDetection(value: Boolean) {
        AppSettings.update { it.copy(speakerDetection = value) }
    }

    fun setSpeakerSensitivity(value: Float) {
        AppSettings.update { it.copy(speakerSensitivity = value) }
    }

    fun setOfflineNotes(value: Boolean) {
        AppSettings.update { it.copy(offlineNotes = value) }
    }

    fun setWordCheck(value: Boolean) {
        AppSettings.update { it.copy(wordCheck = value) }
    }

    fun refreshStorage() {
        viewModelScope.launch { _storage.value = LectureRepository.storageBytes(getApplication()) }
    }

    fun testConnection() {
        val current = AppSettings.state.value
        if (!current.configured) {
            _test.value = TestState.Failure("Enter your server's address first.")
            return
        }
        viewModelScope.launch {
            _test.value = TestState.Testing
            try {
                val models = OllamaClient(AppSettings.baseUrl(current.serverUrl), current.model).listModels()
                val installed = models.any { it == current.model || it == "${current.model}:latest" }
                _test.value = TestState.Success(models, installed)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _test.value = TestState.Failure(e.message ?: "Couldn't connect.")
            }
        }
    }
}
