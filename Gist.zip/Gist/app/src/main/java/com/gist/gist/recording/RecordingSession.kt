package com.gist.gist.recording

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class RecState { Idle, Recording, Paused }

data class SessionState(
    val state: RecState = RecState.Idle,
    val elapsedMs: Long = 0L,
    /** Smoothed microphone level, 0..1. */
    val level: Float = 0f,
    /** True while another app (a call, for example) has taken over the microphone. */
    val micSilenced: Boolean = false,
    val error: String? = null,
    /** Transcript so far, as flowing text with paragraph breaks at longer pauses. */
    val transcript: String = "",
    /** True once the speech model is loaded and listening. */
    val transcribing: Boolean = false,
    /** True after Stop while the last spoken sentences are still being transcribed. */
    val finalizing: Boolean = false,
    /** File name of the audio being recorded right now, if any. */
    val activeFile: String? = null,
    /** Moments flagged during this recording, in ms. */
    val bookmarks: List<Long> = emptyList(),
)

/**
 * The one place the recording service publishes to and the screen reads from.
 * It lives for the whole app process, so the screen can reconnect at any time.
 */
object RecordingSession {

    const val SAMPLE_RATE = 16_000

    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    /** About two seconds of the latest audio, for the transcription step. */
    val preRoll = PcmRingBuffer(SAMPLE_RATE * 2)

    private val _frames = MutableSharedFlow<ShortArray>(
        extraBufferCapacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    /** Live 16 kHz mono frames. Step 3 will decide how the transcriber consumes these. */
    val frames: SharedFlow<ShortArray> = _frames.asSharedFlow()

    internal fun update(block: (SessionState) -> SessionState) {
        _state.update(block)
    }

    internal fun begin(audioFileName: String) {
        preRoll.clear()
        _state.value = SessionState(state = RecState.Recording, activeFile = audioFileName)
    }

    internal fun finish() {
        _state.update {
            it.copy(
                state = RecState.Idle,
                elapsedMs = 0L,
                level = 0f,
                micSilenced = false,
                transcribing = false,
                finalizing = false,
                activeFile = null,
                bookmarks = emptyList(),
            )
        }
    }

    internal fun publishFrame(frame: ShortArray, count: Int) {
        preRoll.write(frame, count)
        _frames.tryEmit(frame.copyOf(count))
    }
}
