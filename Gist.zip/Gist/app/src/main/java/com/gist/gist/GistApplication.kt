package com.gist.gist

import android.app.Application
import com.gist.gist.settings.AppSettings

class GistApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppSettings.init(this)
    }
}
