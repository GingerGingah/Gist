package com.gist.gist.text

import kotlin.math.abs

/*
 * Tidying text that comes out of speech and language models:
 *  - strip noise labels and loops from transcripts,
 *  - turn messy model Markdown (tables, literal "\n", repeated rows) into clean Markdown,
 *  - fix mis-heard words using the user's own vocabulary, by sound.
 */

// ---------------------------------------------------------------- transcripts

private const val NOISE_WORDS =
    "(?:blank[_ ]?audio|audio[_ ]?out|music|buzz\\w*|laugh\\w*|applause|noise|silence|inaudible|crosstalk|sighs?|coughs?)"

private val NOISE = listOf(
    Regex("""\[[^\]\n]{0,40}\]"""),                              // [BLANK_AUDIO], [Music], [AUDIO OUT]
    Regex("""\[[A-Za-z][A-Za-z_ ]{1,20}(?![A-Za-z_\]])"""),      // cut off: [BLANK, [BLANK_AUD
    Regex("\\(\\s*$NOISE_WORDS\\s*\\)", RegexOption.IGNORE_CASE), // (buzz)
    Regex("\\(\\s*$NOISE_WORDS", RegexOption.IGNORE_CASE),        // cut off: (buzz
)

private val REPEAT = Regex("""(?i)\b(\w+(?: \w+){0,3})(?:[,.;]? \1\b){3,}""")
private val WHITESPACE = Regex("\\s+")

/** Removes sound labels such as [BLANK_AUDIO], including ones the model cut off halfway. */
fun stripNoise(text: String): String {
    var t = text
    for (pattern in NOISE) t = pattern.replace(t, " ")
    return t
}

/** "CPU, CPU, CPU, CPU, CPU" (a model stuck in a loop) becomes "CPU". */
fun collapseRepeats(text: String): String = REPEAT.replace(text, "\$1")

/** One transcribed sentence, cleaned. Empty if nothing real was said. */
fun cleanSpoken(text: String): String {
    var t = text.trim().split(WHITESPACE).joinToString(" ")
    t = stripNoise(t)
    t = collapseRepeats(t.trim().split(WHITESPACE).joinToString(" "))
    t = t.replace(Regex("\\s+([,.;!?])"), "\$1")
    t = t.trim(' ', ',', ';', '-')
    return if (Regex("[A-Za-z0-9]").containsMatchIn(t)) t else ""
}

// ---------------------------------------------------------------- Markdown from models

private val SEPARATOR = Regex("""^\s*\|?[\s:\-|]+\|?\s*$""")
private val DASHES = Regex(""":?-{2,}:?""")
private val SKIPPED_SECTIONS = listOf("pronunciation")

/** Makes model output safe to show: no tables, no stray escapes, no repeated lines. */
fun cleanMarkdown(raw: String): String {
    var text = raw.replace("\\n", "\n").replace("\\t", " ").replace("\\|", "|")
    text = Regex("(?i)<br\\s*/?>").replace(text, "\n")
    text = Regex("</?[A-Za-z][^>]*>").replace(text, "")

    val rows = text.lines()
    val out = ArrayList<String>()
    val seen = HashSet<String>()
    var skipping = false

    for ((index, row) in rows.withIndex()) {
        var line = row.trimEnd()
        var stripped = line.trim()

        if (stripped.startsWith("|")) {
            var cells = stripped.trim('|').split("|").map { it.trim() }
            if (cells.filter { it.isNotEmpty() }.all { DASHES.matches(it) }) continue   // the ---|--- line
            val following = if (index + 1 < rows.size) rows[index + 1] else ""
            if (following.contains("-") && SEPARATOR.matches(following)) continue      // the header row
            cells = cells.filter { it.isNotEmpty() }
            if (cells.size > 1 && cells[0].all { it.isDigit() }) cells = cells.drop(1)
            if (cells.isEmpty()) continue
            line = if (cells.size > 1) "- **${cells[0]}**: ${cells.drop(1).joinToString(" — ")}"
            else "- ${cells[0]}"
            stripped = line
        }

        val title = stripped.trimStart('#').trim().trim('*').trim(':').trim().lowercase()
        val isHeading = stripped.startsWith("#")
        if (SKIPPED_SECTIONS.any { title.startsWith(it) } && (isHeading || title.length < 40)) {
            skipping = true
            continue
        }
        if (skipping) {
            if (stripped.isEmpty() || isHeading) skipping = false else continue
        }

        if (stripped.isNotEmpty() && !isHeading) {
            val key = stripped.lowercase().replace(Regex("[^a-z0-9]+"), "")
            if (key.length > 8) {
                if (!seen.add(key)) continue
            }
            line = collapseRepeats(line)
        }
        out.add(line)
    }

    var result = out.joinToString("\n")
    result = Regex("\n{3,}").replace(result, "\n\n")
    return result.trim()
}

// ---------------------------------------------------------------- vocabulary

private val STOP = (
    "the and for are but not you all any can had her was one our out day get has him his how man new " +
        "now old see two way who boy did its let put say she too use that this with have from they will " +
        "would there their what about which when your said each than them then these some into just " +
        "like also over such only very been more here were does"
    ).split(" ").toSet()

private val WORD = Regex("[A-Za-z][A-Za-z0-9'\\-]*")
private val TOKEN = Regex("[A-Za-z][A-Za-z'\\-]*")

private fun lettersOf(word: String) = word.lowercase().filter { it in 'a'..'z' }

/** Splits what the user typed (commas or lines) into the words worth watching for. */
fun normalizeTerms(raw: String): List<String> {
    val terms = ArrayList<String>()
    for (entry in raw.split(Regex("[,\\n;]+"))) {
        val words = WORD.findAll(entry).map { it.value }.toList()
        val minLetters = if (words.size == 1) 3 else 4
        for (word in words) {
            val letters = word.count { it in 'A'..'Z' || it in 'a'..'z' }
            if (letters >= minLetters && word.lowercase() !in STOP && word !in terms) terms.add(word)
        }
    }
    return terms
}

/** A rough "how it sounds" code, so cash and cache, or herds and hertz, match. */
fun phoneticKey(word: String): String {
    var w = lettersOf(word)
    if (w.isEmpty()) return ""
    w = w.replace(Regex("^kn"), "n").replace(Regex("^wr"), "r")
    w = w.replace("x", "ks")
    for ((old, new) in listOf(
        "sch" to "sk", "tch" to "X", "sh" to "X", "ch" to "X", "ph" to "f",
        "ck" to "k", "th" to "t", "wh" to "w", "gh" to "",
    )) w = w.replace(old, new)
    w = w.replace(Regex("c(?=[eiy])"), "s")
    for ((old, new) in listOf(
        "c" to "k", "q" to "k", "z" to "s", "v" to "f", "b" to "p", "d" to "t", "g" to "k",
    )) w = w.replace(old, new)
    if (w.length > 3 && w.endsWith("e")) w = w.dropLast(1)
    w = w.replace(Regex("[aeiouy]"), "a")
    return w.replace(Regex("(.)\\1+"), "\$1")
}

private fun distance(a: String, b: String): Int {
    var previous = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        val current = IntArray(b.length + 1)
        current[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            current[j] = minOf(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + cost)
        }
        previous = current
    }
    return previous[b.length]
}

/** Replaces words that sound like one of the user's terms with the term itself. */
class VocabularyFixer(rawTerms: String) {

    private class Term(val text: String, val letters: String, val key: String)

    val terms: List<String> = normalizeTerms(rawTerms)
    private val info = terms.map { Term(it, lettersOf(it), phoneticKey(it)) }
    private val exact = info.map { it.letters }.toSet()

    val active: Boolean get() = terms.isNotEmpty()

    /** Returns the text and how many words were replaced. */
    fun fix(text: String): Pair<String, Int> {
        if (!active) return Pair(text, 0)
        var count = 0
        val result = TOKEN.replace(text) { match ->
            val token = match.value
            val term = best(token)
            if (term == null) {
                token
            } else {
                count++
                rewrap(token, term)
            }
        }
        return Pair(result, count)
    }

    private fun best(token: String): String? {
        val letters = lettersOf(token)
        if (letters.length < 3 || letters in STOP || letters in exact) return null
        val key = phoneticKey(token)
        var bestTerm: String? = null
        var bestScore = 99.0
        for (t in info) {
            // Plurals and endings of the same word are not mistakes.
            if (letters.startsWith(t.letters) || t.letters.startsWith(letters)) {
                if (abs(letters.length - t.letters.length) <= 3) continue
            }
            val base = when {
                key == t.key -> 0.0
                key.length >= 5 && distance(key, t.key) <= 1 -> 1.0
                else -> continue
            }
            val score = base + distance(letters, t.letters) / 100.0
            if (score < bestScore) {
                bestTerm = t.text
                bestScore = score
            }
        }
        return bestTerm
    }

    private fun rewrap(token: String, term: String): String = when {
        token.length > 1 && token.all { !it.isLetter() || it.isUpperCase() } -> term.uppercase()
        token[0].isUpperCase() && term[0].isLowerCase() -> term[0].uppercase() + term.substring(1)
        else -> term
    }
}
