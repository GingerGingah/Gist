package com.gist.gist.recording

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.gist.gist.MainActivity
import com.gist.gist.notes.PostProcessing
import com.gist.gist.settings.AppSettings
import com.gist.gist.R
import com.gist.gist.transcription.ModelStore
import com.gist.gist.transcription.TranscriptionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Keeps recording and transcribing when the screen is off or Gist is in the background. The
 * screen only sends it commands (start, pause, resume, stop) and reads progress from
 * [RecordingSession].
 */
class RecordingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var capture: AudioCapture? = null
    private var engine: TranscriptionEngine? = null
    private var notifJob: Job? = null
    private var stopping = false
    private var metaFile: File? = null
    private var meta: JSONObject? = null
    private var currentBase: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID, "Recording", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Shown while Gist is recording a lecture" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent?.getStringExtra(EXTRA_SUBJECT).orEmpty())
            ACTION_PAUSE -> capture?.setPaused(true)
            ACTION_RESUME -> capture?.setPaused(false)
            ACTION_STOP -> stopRecording()
            ACTION_BOOKMARK -> addBookmark()
            else -> if (capture == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startRecording(subject: String) {
        // Must happen right away after startForegroundService, even if we end up not recording.
        try {
            ServiceCompat.startForeground(
                this,
                NOTIF_ID,
                buildNotification(RecordingSession.state.value),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
            )
        } catch (e: Exception) {
            RecordingSession.update {
                it.copy(error = "Couldn't start recording. Check the microphone permission.")
            }
            stopSelf()
            return
        }
        if (capture != null || stopping) return

        val dir = File(filesDir, "recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val audioFile = File(dir, "lecture_$stamp.wav")
        val transcriptFile = File(dir, "lecture_$stamp.txt")
        val timingFile = File(dir, "lecture_$stamp.jsonl")
        currentBase = audioFile.nameWithoutExtension
        metaFile = File(dir, "lecture_$stamp.json")
        meta = JSONObject()
            .put("audioFile", audioFile.name)
            .put("subject", subject)
            .put("startedAt", System.currentTimeMillis())
            .put("durationMs", 0L)

        RecordingSession.begin(audioFile.name)

        // The engine subscribes to the microphone frames first, so nothing is missed while the
        // speech model loads. Without the model we still record audio.
        engine = if (ModelStore.isReady(this)) {
            meta?.put("transcriptFile", transcriptFile.name)
            val prefs = AppSettings.state.value
            val speakerModel = if (prefs.speakerDetection && ModelStore.isReady(this, ModelStore.speaker)) {
                File(ModelStore.dir(this, ModelStore.speaker), ModelStore.SPEAKER_FILE)
            } else {
                null
            }
            TranscriptionEngine(
                ModelStore.dir(this), transcriptFile, timingFile, speakerModel, prefs.speakerSensitivity,
                prefs.vocabulary, prefs.sentencePause,
            ).also { it.start(scope) }
        } else {
            null
        }
        saveMeta()

        capture = AudioCapture(this, audioFile) { message ->
            scope.launch {
                RecordingSession.update { it.copy(error = message) }
                stopRecording()
            }
        }.also { it.start(scope) }

        notifJob = scope.launch {
            RecordingSession.state
                .map { Triple(it.state, it.elapsedMs / 1000, it.micSilenced) }
                .distinctUntilChanged()
                .collect { refreshNotification() }
        }
    }

    private fun stopRecording() {
        if (stopping) return
        val active = capture
        if (active == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        stopping = true
        notifJob?.cancel()
        val eng = engine
        scope.launch {
            active.stopAndJoin()
            if (eng != null) {
                // Let the last spoken sentences finish transcribing before shutting down.
                RecordingSession.update { it.copy(finalizing = true) }
                refreshNotification()
                eng.finish()
            }
            saveMeta()
            // If asked to: check the words, then write the notes (each waits for what it needs).
            val base = currentBase
            if (eng != null && base != null) PostProcessing.afterRecording(applicationContext, base)
            RecordingSession.finish()
            engine = null
            capture = null
            stopping = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun addBookmark() {
        if (capture == null || stopping) return
        val at = RecordingSession.state.value.elapsedMs
        RecordingSession.update { it.copy(bookmarks = it.bookmarks + at) }
        meta?.put("bookmarks", JSONArray(RecordingSession.state.value.bookmarks))
        saveMeta()
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(RecordingSession.state.value))
    }

    private fun saveMeta() {
        val file = metaFile ?: return
        val json = meta ?: return
        json.put("durationMs", RecordingSession.state.value.elapsedMs)
        try {
            file.writeText(json.toString(2))
        } catch (e: IOException) {
            // The audio is the important part; the info file can be rebuilt.
        }
    }

    private fun buildNotification(state: SessionState): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        fun action(label: String, action: String, code: Int) = NotificationCompat.Action.Builder(
            0,
            label,
            PendingIntent.getService(
                this, code,
                Intent(this, RecordingService::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        ).build()

        val paused = state.state == RecState.Paused
        val title = when {
            state.finalizing -> "Gist is finishing up"
            paused -> "Gist is paused"
            else -> "Gist is recording"
        }
        val text = when {
            state.finalizing -> "Finishing the transcript…"
            state.micSilenced -> "Another app is using the microphone"
            else -> formatElapsed(state.elapsedMs)
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
        if (!state.finalizing) {
            builder
                .addAction(
                    action(
                        if (paused) "Resume" else "Pause",
                        if (paused) ACTION_RESUME else ACTION_PAUSE,
                        1,
                    )
                )
                .addAction(action("Bookmark", ACTION_BOOKMARK, 3))
                .addAction(action("Stop", ACTION_STOP, 2))
        }
        return builder.build()
    }

    override fun onDestroy() {
        capture?.cancel()
        engine?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "recording"
        private const val NOTIF_ID = 1

        const val ACTION_START = "com.gist.gist.action.START"
        const val ACTION_PAUSE = "com.gist.gist.action.PAUSE"
        const val ACTION_RESUME = "com.gist.gist.action.RESUME"
        const val ACTION_STOP = "com.gist.gist.action.STOP"
        const val ACTION_BOOKMARK = "com.gist.gist.action.BOOKMARK"
        private const val EXTRA_SUBJECT = "subject"

        fun start(context: Context, subject: String) {
            val intent = Intent(context, RecordingService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_SUBJECT, subject)
            ContextCompat.startForegroundService(context, intent)
        }

        fun send(context: Context, action: String) {
            context.startService(Intent(context, RecordingService::class.java).setAction(action))
        }

        fun formatElapsed(ms: Long): String {
            val total = ms / 1000
            val h = total / 3600
            val m = (total % 3600) / 60
            val s = total % 60
            return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
        }
    }
}
