package com.gist.gist.ui.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.gist.gist.data.Lecture
import com.gist.gist.data.TranscriptLine
import com.gist.gist.notes.LectureNotes
import com.gist.gist.ui.formatClock
import com.gist.gist.ui.formatDate
import com.gist.gist.ui.formatDuration
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Export {

    fun transcriptText(lecture: Lecture, lines: List<TranscriptLine>): String = buildString {
        appendLine(lecture.title)
        appendLine("${formatDate(lecture.startedAt)} · ${formatDuration(lecture.durationMs)}")
        appendLine()
        if (lines.isEmpty()) {
            append("(No transcript)")
        } else {
            val multi = lines.any { it.speaker > 0 }
            var last = -1
            lines.forEach {
                val who = if (multi && it.speaker != last) "Speaker ${it.speaker + 1}: " else ""
                last = it.speaker
                appendLine("[${formatClock(it.startMs)}] $who${it.text}")
            }
        }
    }.trimEnd()

    /** A safe file name such as "Signals_and_Systems_2026-10-14". */
    fun baseName(lecture: Lecture): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(lecture.startedAt))
        val cleaned = "${lecture.title} $date"
            .replace(Regex("[^A-Za-z0-9 _-]"), "")
            .trim()
            .replace(' ', '_')
        return cleaned.ifBlank { lecture.id }
    }

    fun shareText(context: Context, lecture: Lecture, lines: List<TranscriptLine>) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, lecture.title)
            putExtra(Intent.EXTRA_TEXT, transcriptText(lecture, lines))
        }
        context.startActivity(Intent.createChooser(intent, "Share transcript"))
    }

    fun shareAudio(context: Context, lecture: Lecture) {
        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.files", lecture.audioFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share audio"))
    }

    fun notesText(lecture: Lecture, notes: LectureNotes): String = buildString {
        appendLine(lecture.title)
        appendLine("${formatDate(lecture.startedAt)} · ${formatDuration(lecture.durationMs)}")
        appendLine()
        if (notes.overview.isNotBlank()) {
            appendLine("OVERVIEW")
            appendLine(notes.overview)
            appendLine()
        }
        if (notes.keyTerms.isNotBlank()) {
            appendLine("KEY TERMS")
            appendLine(notes.keyTerms)
            appendLine()
        }
        notes.sections.forEach {
            appendLine("${formatClock(it.startMs)} – ${formatClock(it.endMs)}")
            appendLine(it.markdown)
            appendLine()
        }
        if (notes.questions.isNotBlank()) {
            appendLine("REVIEW QUESTIONS")
            appendLine(notes.questions)
        }
    }.replace("**", "").trimEnd()

    fun shareNotes(context: Context, lecture: Lecture, notes: LectureNotes) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${lecture.title} – notes")
            putExtra(Intent.EXTRA_TEXT, notesText(lecture, notes))
        }
        context.startActivity(Intent.createChooser(intent, "Share notes"))
    }

    fun writeAudio(context: Context, lecture: Lecture, uri: Uri): Boolean = try {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            lecture.audioFile.inputStream().use { it.copyTo(out) }
        } != null
    } catch (e: IOException) {
        false
    }

    fun writeText(context: Context, uri: Uri, text: String): Boolean = try {
        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) } != null
    } catch (e: IOException) {
        false
    }
}
