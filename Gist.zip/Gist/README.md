# Gist

Offline lecture transcription for Android (built around the Galaxy Z Fold4).
Package: com.gist.gist

## First-time setup
1. Unzip this folder somewhere (not over another project).
2. Open a PowerShell window in this folder and run:
       powershell -ExecutionPolicy Bypass -File .\setup-sherpa.ps1
   This adds the speech library (native files plus its Kotlin wrapper). It needs internet.
   (Moving from an older copy? You can instead copy app/src/main/jniLibs and
   app/src/main/java/com/k2fsa from it into this folder.)
3. In Android Studio: File -> Open -> this folder. Use Gradle 8.9 or newer if asked. Sync.
4. Run on the phone (USB debugging on).
5. On first launch, tap "Download" on the card to fetch the speech model (about 400 MB, Wi-Fi by
   default). After that everything works offline.

If Android Studio reports "Unresolved reference: k2fsa", step 2 hasn't been run yet.

Note: the package name changed from com.logan.gist, so Android treats this as a new app. The old
app's recordings and downloaded model stay with the old app until you uninstall it.

## AI notes (optional)
Notes are written by a small model on your own home server and reached over Tailscale.
Follow SERVER-SETUP.md, then enter the server's address in Settings. Open a lecture, go to its
Notes tab and tap Write notes (or switch on "Write notes automatically" in Settings).
Only the transcript text is sent, never the audio. Jobs run in the background, wait for the
server if it is unreachable, and resume from the last finished part.

## Optional extras (all downloaded on request, all work offline once installed)
Settings asks "Download prerequisites?" the first time you switch one on.
- **Speakers (about 26 MB):** tells voices apart while recording. Labels appear live ("Speaker 2:")
  and in the lecture (S1, S2). Speaker 1 is whoever talks first. A Sensitivity slider fixes one
  person being split in two (move left) or different people being merged (move right).
- **Offline AI (about 1.6 GB):** a small model (Qwen 2.5 1.5B) running on the phone through
  Google MediaPipe. It powers two optional features:
  - *Full offline mode:* writes the notes on the phone, with no server and no internet.
  - *Check words in context:* after each lecture, proofreads the transcript and fixes clearly
    mis-heard words (for example "cash" for "cache"). Strict safety checks reject any change that
    isn't a small, plausible fix. Corrections are saved on the side: changed words are underlined,
    and you can Show original or Undo at any time.
  Both wait while you record and only start when the battery isn't low.

## Getting words right
- **My vocabulary** (Settings → Live transcription): list the terms of your subject, for example
  `cache, hertz, opcode, operand, accumulator`. While recording, anything that sounds like one of
  them is swapped for it, so "cash" becomes "cache" and "herds" becomes "hertz". Only add specific
  terms: a word that sounds like an everyday word will always be swapped.
- For a lecture already recorded, open it and choose **Fix terms from my vocabulary** in its
  menu (also available for several lectures at once). It is instant, needs no AI, and can be undone.
- **Pause that ends a sentence** (same card): longer means whole sentences for the speech model,
  so better accuracy and fewer fragments; shorter shows text sooner. Default 0.8 s.
- Sound labels like [BLANK_AUDIO] and loops like "CPU, CPU, CPU..." are removed automatically.
- Notes are tidied too: tables, stray "\n" and repeated lines are cleaned up, and notes written
  earlier are cleaned when displayed. "Write notes again" regenerates them with stricter instructions.
- Best accuracy still comes from the microphone being close to the speaker.

## Using it
- Record tab: start, pause and stop a lecture. The transcript appears live. Tap the bookmark
  button (or the Bookmark button in the notification, with the screen off) to flag a moment;
  bookmarks show as chips in the lecture and are passed to the AI as important.
- Lectures tab: every saved lecture, grouped by day, with filter chips when you have several
  subjects. Search covers subjects, transcripts and notes.
- Press and hold a lecture to select it, then tap others to add or remove them. The bar at the
  top then offers: select all, share (transcripts, notes or audio as files), delete, and under
  the three dots: write notes, check words with AI, set subject, and save everything to a folder
  you choose. Back or the X leaves selection mode.
- Playback has 0.75x to 2x speed and 10-second skips.
- Open a lecture to play the audio, tap any line to jump to that moment, and use the menu to
  share, save to a folder of your choice, rename or delete.
- While a lecture plays, the line being spoken is highlighted and its words light up one by
  one. Timing is exact per spoken stretch and estimated within it (spread over the letters, with
  short pauses at punctuation). If the speech model supplies its own token timings they are
  used instead. Lectures recorded before this version have no saved timings, so their line ends
  are estimated too.
- Folded (cover screen): bottom tabs, one screen at a time.
  Unfolded (inner screen): a side rail; Record shows controls beside the live transcript, and
  Lectures shows the list beside the open lecture. Playback carries on when you fold or unfold.

## How transcription works
- Silero voice detection cuts the audio at pauses of about half a second.
- Each spoken stretch is transcribed by Whisper small (English, 8-bit) and appended live.
- The transcript is saved as it goes, next to the audio.
- Tune in transcription/TranscriptionEngine.kt: NUM_THREADS, minSilenceDuration, maxSpeechDuration.

## Where recordings go
App-private storage: files/recordings/lecture_<date>_<time>.wav (16 kHz mono), a matching .txt
with timestamped transcript lines, a .jsonl with exact timings per line (used for the letter
highlight), and a .json with subject, start time and duration.
In Android Studio: View -> Tool Windows -> Device Explorer -> data/data/com.gist.gist/files/recordings
The speech model lives in Android/data/com.gist.gist/files/models.
Uninstalling the app deletes recordings, so use Save to... or Share for anything important.

## Status
- [x] Step 1: project setup, recording screen, mic permission
- [x] Step 2: real audio capture (foreground service, crash-safe saving, level meter)
- [x] Step 3: on-device Whisper transcription with first-launch model download
- [x] Step 4: lectures list, transcript view, playback, search, share and export
- [x] Step 5: Fold two-pane layout and letter-by-letter highlight during playback
- [x] Step 6: AI notes from your home server, plus settings, bookmarks, playback speed and a
      refreshed look
